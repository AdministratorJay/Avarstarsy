
package net.mcreator.avarstarsy.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

import net.mcreator.avarstarsy.entity.INFINITYBIPEDEntity;

public class INFINITYBIPEDRenderer extends HumanoidMobRenderer<INFINITYBIPEDEntity, HumanoidModel<INFINITYBIPEDEntity>> {
	public INFINITYBIPEDRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
				new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR))));
	}

	@Override
	public ResourceLocation getTextureLocation(INFINITYBIPEDEntity entity) {
		return new ResourceLocation("avarstarsy:textures/entities/20200720155724-3a418f335a8813495e189a89c021d370-desktop.png");
	}
}
