
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.avarstarsy.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.avarstarsy.block.UltimateBlockBlock;
import net.mcreator.avarstarsy.block.StarrySkyBlockBlock;
import net.mcreator.avarstarsy.block.AdministratorBlockBlock;
import net.mcreator.avarstarsy.AvarstarsyMod;

public class AvarstarsyModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, AvarstarsyMod.MODID);
	public static final RegistryObject<Block> ULTIMATE_BLOCK = REGISTRY.register("ultimate_block", () -> new UltimateBlockBlock());
	public static final RegistryObject<Block> ADMINISTRATOR_BLOCK = REGISTRY.register("administrator_block", () -> new AdministratorBlockBlock());
	public static final RegistryObject<Block> STARRY_SKY_BLOCK = REGISTRY.register("starry_sky_block", () -> new StarrySkyBlockBlock());
}
