
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.avarstarsy.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.avarstarsy.client.renderer.TestRenderer;
import net.mcreator.avarstarsy.client.renderer.INFINITYBIPEDRenderer;
import net.mcreator.avarstarsy.client.renderer.HerobineRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class AvarstarsyModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(AvarstarsyModEntities.AVARITIA_ARROW.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(AvarstarsyModEntities.HEROBINE.get(), HerobineRenderer::new);
		event.registerEntityRenderer(AvarstarsyModEntities.INFINITYBIPED.get(), INFINITYBIPEDRenderer::new);
		event.registerEntityRenderer(AvarstarsyModEntities.INFINITY.get(), TestRenderer::new);
		event.registerEntityRenderer(AvarstarsyModEntities.INFINITY_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(AvarstarsyModEntities.ENTITYREMOVER.get(), ThrownItemRenderer::new);
	}
}
