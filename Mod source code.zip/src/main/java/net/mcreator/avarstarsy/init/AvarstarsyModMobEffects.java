
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.avarstarsy.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.avarstarsy.potion.InvincibleMobEffect;
import net.mcreator.avarstarsy.potion.DiedMobEffect;
import net.mcreator.avarstarsy.AvarstarsyMod;

public class AvarstarsyModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, AvarstarsyMod.MODID);
	public static final RegistryObject<MobEffect> DIED = REGISTRY.register("died", () -> new DiedMobEffect());
	public static final RegistryObject<MobEffect> INVINCIBLE = REGISTRY.register("invincible", () -> new InvincibleMobEffect());
}
