
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.avarstarsy.init;

import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.GameRules;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class AvarstarsyModGameRules {
	public static final GameRules.Key<GameRules.BooleanValue> PICKAXEUNBREAKING = GameRules.register("pickaxeUNbreaking", GameRules.Category.PLAYER,
			GameRules.BooleanValue.create(true));
	public static final GameRules.Key<GameRules.BooleanValue> PICKAXEUNBREAKINGDESTORY = GameRules.register("pickaxeunbreakingdestory",
			GameRules.Category.DROPS, GameRules.BooleanValue.create(true));
}
