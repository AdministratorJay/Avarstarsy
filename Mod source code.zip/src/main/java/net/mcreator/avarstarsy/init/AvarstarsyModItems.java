
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.avarstarsy.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.avarstarsy.item.ZeroItem;
import net.mcreator.avarstarsy.item.YaSuoDingWuItem;
import net.mcreator.avarstarsy.item.YaSuoDingSiItem;
import net.mcreator.avarstarsy.item.YaSuoDingQiItem;
import net.mcreator.avarstarsy.item.YaSuoDingLiuItem;
import net.mcreator.avarstarsy.item.YaSuoDingJiuItem;
import net.mcreator.avarstarsy.item.YaSuoDingItem;
import net.mcreator.avarstarsy.item.YaSuoDingErItem;
import net.mcreator.avarstarsy.item.YaSuoDingBaItem;
import net.mcreator.avarstarsy.item.YaSuoDing3Item;
import net.mcreator.avarstarsy.item.SmallWoodSwordItem;
import net.mcreator.avarstarsy.item.NANItem;
import net.mcreator.avarstarsy.item.LogoItem;
import net.mcreator.avarstarsy.item.KillitemItem;
import net.mcreator.avarstarsy.item.InfinitybipedspawneggItem;
import net.mcreator.avarstarsy.item.InfinitySwordItem;
import net.mcreator.avarstarsy.item.InfinityShovelItem;
import net.mcreator.avarstarsy.item.InfinityPickaxeItem;
import net.mcreator.avarstarsy.item.InfinityIngotItem;
import net.mcreator.avarstarsy.item.InfinityHoeItem;
import net.mcreator.avarstarsy.item.InfinityHammerItem;
import net.mcreator.avarstarsy.item.InfinityAxeItem;
import net.mcreator.avarstarsy.item.InfinityArmorItem;
import net.mcreator.avarstarsy.item.GgItem;
import net.mcreator.avarstarsy.item.ForgestownItem;
import net.mcreator.avarstarsy.item.ForgestartItem;
import net.mcreator.avarstarsy.item.EntityremoverItem;
import net.mcreator.avarstarsy.item.EmptywpItem;
import net.mcreator.avarstarsy.item.EasySwordItem;
import net.mcreator.avarstarsy.item.EasyShovelItem;
import net.mcreator.avarstarsy.item.EasyPickaxeItem;
import net.mcreator.avarstarsy.item.EasyHoeItem;
import net.mcreator.avarstarsy.item.EasyAxeItem;
import net.mcreator.avarstarsy.item.EasyArmorItem;
import net.mcreator.avarstarsy.item.DeleteInfinityBipedItem;
import net.mcreator.avarstarsy.item.ClearItem;
import net.mcreator.avarstarsy.item.BbItem;
import net.mcreator.avarstarsy.item.AzItem;
import net.mcreator.avarstarsy.item.Az11Item;
import net.mcreator.avarstarsy.item.AvaritiaArrowItem;
import net.mcreator.avarstarsy.AvarstarsyMod;

public class AvarstarsyModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, AvarstarsyMod.MODID);
	public static final RegistryObject<Item> INFINITY_ARMOR_HELMET = REGISTRY.register("infinity_armor_helmet", () -> new InfinityArmorItem.Helmet());
	public static final RegistryObject<Item> INFINITY_ARMOR_CHESTPLATE = REGISTRY.register("infinity_armor_chestplate",
			() -> new InfinityArmorItem.Chestplate());
	public static final RegistryObject<Item> INFINITY_ARMOR_LEGGINGS = REGISTRY.register("infinity_armor_leggings",
			() -> new InfinityArmorItem.Leggings());
	public static final RegistryObject<Item> INFINITY_ARMOR_BOOTS = REGISTRY.register("infinity_armor_boots", () -> new InfinityArmorItem.Boots());
	public static final RegistryObject<Item> INFINITY_SWORD = REGISTRY.register("infinity_sword", () -> new InfinitySwordItem());
	public static final RegistryObject<Item> INFINITY_PICKAXE = REGISTRY.register("infinity_pickaxe", () -> new InfinityPickaxeItem());
	public static final RegistryObject<Item> INFINITY_AXE = REGISTRY.register("infinity_axe", () -> new InfinityAxeItem());
	public static final RegistryObject<Item> INFINITY_SHOVEL = REGISTRY.register("infinity_shovel", () -> new InfinityShovelItem());
	public static final RegistryObject<Item> INFINITY_HOE = REGISTRY.register("infinity_hoe", () -> new InfinityHoeItem());
	public static final RegistryObject<Item> AVARITIA_ARROW = REGISTRY.register("avaritia_arrow", () -> new AvaritiaArrowItem());
	public static final RegistryObject<Item> EASY_ARMOR_HELMET = REGISTRY.register("easy_armor_helmet", () -> new EasyArmorItem.Helmet());
	public static final RegistryObject<Item> EASY_ARMOR_CHESTPLATE = REGISTRY.register("easy_armor_chestplate", () -> new EasyArmorItem.Chestplate());
	public static final RegistryObject<Item> EASY_ARMOR_LEGGINGS = REGISTRY.register("easy_armor_leggings", () -> new EasyArmorItem.Leggings());
	public static final RegistryObject<Item> EASY_ARMOR_BOOTS = REGISTRY.register("easy_armor_boots", () -> new EasyArmorItem.Boots());
	public static final RegistryObject<Item> EASY_SWORD = REGISTRY.register("easy_sword", () -> new EasySwordItem());
	public static final RegistryObject<Item> EASY_PICKAXE = REGISTRY.register("easy_pickaxe", () -> new EasyPickaxeItem());
	public static final RegistryObject<Item> EASY_AXE = REGISTRY.register("easy_axe", () -> new EasyAxeItem());
	public static final RegistryObject<Item> EASY_SHOVEL = REGISTRY.register("easy_shovel", () -> new EasyShovelItem());
	public static final RegistryObject<Item> EASY_HOE = REGISTRY.register("easy_hoe", () -> new EasyHoeItem());
	public static final RegistryObject<Item> ENTITY_REMOVER = REGISTRY.register("entity_remover", () -> new SmallWoodSwordItem());
	public static final RegistryObject<Item> INFINITY_INGOT = REGISTRY.register("infinity_ingot", () -> new InfinityIngotItem());
	public static final RegistryObject<Item> HEROBINE = REGISTRY.register("herobine_spawn_egg",
			() -> new ForgeSpawnEggItem(AvarstarsyModEntities.HEROBINE, -16777216, -16777216,
					new Item.Properties().tab(AvarstarsyModTabs.TAB_AVARSTARSY)));
	public static final RegistryObject<Item> GIVE_KILLITEM_STICK = REGISTRY.register("give_killitem_stick", () -> new DeleteInfinityBipedItem());
	public static final RegistryObject<Item> NAN = REGISTRY.register("nan", () -> new NANItem());
	public static final RegistryObject<Item> ULTIMATE_BLOCK = block(AvarstarsyModBlocks.ULTIMATE_BLOCK, AvarstarsyModTabs.TAB_AVARSTARSY);
	public static final RegistryObject<Item> INFINITY_HAMMER = REGISTRY.register("infinity_hammer", () -> new InfinityHammerItem());
	public static final RegistryObject<Item> KILLITEM = REGISTRY.register("killitem", () -> new KillitemItem());
	public static final RegistryObject<Item> LOGO = REGISTRY.register("logo", () -> new LogoItem());
	public static final RegistryObject<Item> ZERO = REGISTRY.register("zero", () -> new ZeroItem());
	public static final RegistryObject<Item> CLEAR = REGISTRY.register("clear", () -> new ClearItem());
	public static final RegistryObject<Item> GG = REGISTRY.register("gg", () -> new GgItem());
	public static final RegistryObject<Item> INFINITY = REGISTRY.register("infinity_spawn_egg",
			() -> new ForgeSpawnEggItem(AvarstarsyModEntities.INFINITY, -1, -1, new Item.Properties().tab(AvarstarsyModTabs.TAB_AVARSTARSY)));
	public static final RegistryObject<Item> AZ = REGISTRY.register("az", () -> new AzItem());
	public static final RegistryObject<Item> AZ_11 = REGISTRY.register("az_11", () -> new Az11Item());
	public static final RegistryObject<Item> ADMINISTRATOR_BLOCK = block(AvarstarsyModBlocks.ADMINISTRATOR_BLOCK, AvarstarsyModTabs.TAB_AVARSTARSY);
	public static final RegistryObject<Item> BB = REGISTRY.register("bb", () -> new BbItem());
	public static final RegistryObject<Item> EMPTYWP = REGISTRY.register("emptywp", () -> new EmptywpItem());
	public static final RegistryObject<Item> ENTITYREMOVER = REGISTRY.register("entityremover", () -> new EntityremoverItem());
	public static final RegistryObject<Item> YA_SUO_DING = REGISTRY.register("ya_suo_ding", () -> new YaSuoDingItem());
	public static final RegistryObject<Item> YA_SUO_DING_ER = REGISTRY.register("ya_suo_ding_er", () -> new YaSuoDingErItem());
	public static final RegistryObject<Item> YA_SUO_DING_3 = REGISTRY.register("ya_suo_ding_3", () -> new YaSuoDing3Item());
	public static final RegistryObject<Item> YA_SUO_DING_SI = REGISTRY.register("ya_suo_ding_si", () -> new YaSuoDingSiItem());
	public static final RegistryObject<Item> YA_SUO_DING_WU = REGISTRY.register("ya_suo_ding_wu", () -> new YaSuoDingWuItem());
	public static final RegistryObject<Item> YA_SUO_DING_LIU = REGISTRY.register("ya_suo_ding_liu", () -> new YaSuoDingLiuItem());
	public static final RegistryObject<Item> YA_SUO_DING_QI = REGISTRY.register("ya_suo_ding_qi", () -> new YaSuoDingQiItem());
	public static final RegistryObject<Item> YA_SUO_DING_BA = REGISTRY.register("ya_suo_ding_ba", () -> new YaSuoDingBaItem());
	public static final RegistryObject<Item> YA_SUO_DING_JIU = REGISTRY.register("ya_suo_ding_jiu", () -> new YaSuoDingJiuItem());
	public static final RegistryObject<Item> STARRY_SKY_BLOCK = block(AvarstarsyModBlocks.STARRY_SKY_BLOCK, AvarstarsyModTabs.TAB_AVARSTARSY);
	public static final RegistryObject<Item> INFINITYBIPEDSPAWNEGG = REGISTRY.register("infinitybipedspawnegg",
			() -> new InfinitybipedspawneggItem());
	public static final RegistryObject<Item> FORGESTOWN = REGISTRY.register("forgestown", () -> new ForgestownItem());
	public static final RegistryObject<Item> FORGESTART = REGISTRY.register("forgestart", () -> new ForgestartItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
