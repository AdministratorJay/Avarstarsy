
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.avarstarsy.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.avarstarsy.entity.TestEntityProjectile;
import net.mcreator.avarstarsy.entity.TestEntity;
import net.mcreator.avarstarsy.entity.INFINITYBIPEDEntity;
import net.mcreator.avarstarsy.entity.HerobineEntity;
import net.mcreator.avarstarsy.entity.EntityremoverEntity;
import net.mcreator.avarstarsy.entity.AvaritiaArrowEntity;
import net.mcreator.avarstarsy.AvarstarsyMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class AvarstarsyModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, AvarstarsyMod.MODID);
	public static final RegistryObject<EntityType<AvaritiaArrowEntity>> AVARITIA_ARROW = register("projectile_avaritia_arrow",
			EntityType.Builder.<AvaritiaArrowEntity>of(AvaritiaArrowEntity::new, MobCategory.MISC).setCustomClientFactory(AvaritiaArrowEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<HerobineEntity>> HEROBINE = register("herobine",
			EntityType.Builder.<HerobineEntity>of(HerobineEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(10000).setUpdateInterval(3).setCustomClientFactory(HerobineEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<INFINITYBIPEDEntity>> INFINITYBIPED = register("infinitybiped",
			EntityType.Builder.<INFINITYBIPEDEntity>of(INFINITYBIPEDEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(10000).setUpdateInterval(3).setCustomClientFactory(INFINITYBIPEDEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<TestEntity>> INFINITY = register("infinity",
			EntityType.Builder.<TestEntity>of(TestEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(TestEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<TestEntityProjectile>> INFINITY_PROJECTILE = register("projectile_infinity",
			EntityType.Builder.<TestEntityProjectile>of(TestEntityProjectile::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(1).setCustomClientFactory(TestEntityProjectile::new).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<EntityremoverEntity>> ENTITYREMOVER = register("projectile_entityremover",
			EntityType.Builder.<EntityremoverEntity>of(EntityremoverEntity::new, MobCategory.MISC).setCustomClientFactory(EntityremoverEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			HerobineEntity.init();
			INFINITYBIPEDEntity.init();
			TestEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(HEROBINE.get(), HerobineEntity.createAttributes().build());
		event.put(INFINITYBIPED.get(), INFINITYBIPEDEntity.createAttributes().build());
		event.put(INFINITY.get(), TestEntity.createAttributes().build());
	}
}
