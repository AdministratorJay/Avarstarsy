
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.avarstarsy.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

import net.mcreator.avarstarsy.world.inventory.SLMenu;
import net.mcreator.avarstarsy.world.inventory.EmptyMenu;
import net.mcreator.avarstarsy.AvarstarsyMod;

public class AvarstarsyModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, AvarstarsyMod.MODID);
	public static final RegistryObject<MenuType<EmptyMenu>> EMPTY = REGISTRY.register("empty", () -> IForgeMenuType.create(EmptyMenu::new));
	public static final RegistryObject<MenuType<SLMenu>> SL = REGISTRY.register("sl", () -> IForgeMenuType.create(SLMenu::new));
}
