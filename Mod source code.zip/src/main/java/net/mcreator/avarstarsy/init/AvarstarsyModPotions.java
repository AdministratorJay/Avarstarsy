
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.avarstarsy.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.avarstarsy.AvarstarsyMod;

public class AvarstarsyModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, AvarstarsyMod.MODID);
	public static final RegistryObject<Potion> DIED_POITION = REGISTRY.register("died_poition",
			() -> new Potion(new MobEffectInstance(AvarstarsyModMobEffects.DIED.get(), 72000, 1, false, false)));
	public static final RegistryObject<Potion> INVINCIBLE_POITION = REGISTRY.register("invincible_poition",
			() -> new Potion(new MobEffectInstance(AvarstarsyModMobEffects.INVINCIBLE.get(), 2400, 1, false, false)));
}
