
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.avarstarsy.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;

public class AvarstarsyModTabs {
	public static CreativeModeTab TAB_AVARSTARSY;

	public static void load() {
		TAB_AVARSTARSY = new CreativeModeTab("tabavarstarsy") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(AvarstarsyModItems.LOGO.get());
			}

			@Override
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
}
