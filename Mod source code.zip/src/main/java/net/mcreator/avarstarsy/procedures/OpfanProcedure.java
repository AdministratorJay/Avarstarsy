package net.mcreator.avarstarsy.procedures;

import net.minecraft.world.entity.Entity;

public class OpfanProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.getPersistentData().putBoolean("fanc", (false));
	}
}
