package net.mcreator.avarstarsy.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;

public class EasySwordDangShiTiBeiGongJuJiZhongShiProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.hurt(DamageSource.GENERIC, 2147483647);
		if (entity instanceof LivingEntity _entity)
			_entity.hurt(new DamageSource("").bypassArmor(), 2147483647);
	}
}
