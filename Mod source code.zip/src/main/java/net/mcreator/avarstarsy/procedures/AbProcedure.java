package net.mcreator.avarstarsy.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.server.level.ServerLevel;

import net.mcreator.avarstarsy.init.AvarstarsyModEntities;
import net.mcreator.avarstarsy.entity.INFINITYBIPEDEntity;

public class AbProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (!entity.level.isClientSide())
			entity.discard();
		if (entity instanceof LivingEntity _entity)
			_entity.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 1, (false), (false)));
		entity.clearFire();
		if (entity instanceof LivingEntity _entity)
			_entity.setHealth((float) Double.POSITIVE_INFINITY);
		if (entity instanceof Player _player) {
			_player.getAbilities().mayfly = (entity instanceof INFINITYBIPEDEntity);
			_player.onUpdateAbilities();
		}
		if (entity instanceof Player _player) {
			_player.getAbilities().mayBuild = (entity instanceof INFINITYBIPEDEntity);
			_player.onUpdateAbilities();
		}
		if (entity instanceof Player _player)
			_player.getFoodData().setFoodLevel((int) Double.POSITIVE_INFINITY);
		if (entity instanceof Player _player)
			_player.getFoodData().setSaturation((float) Double.POSITIVE_INFINITY);
		entity.setAirSupply(0);
		if (entity instanceof LivingEntity _entity)
			_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
		if (entity instanceof LivingEntity _entity)
			_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
					+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));/*player.isDead = false;*/
		/*player.deathTime = 0;*/
		/*player.ticksExisted = 0;*/
		/*GuiIngameForge.renderHealth = true;*/
		/*player.updateBlocked = false;*/
		if (world instanceof ServerLevel _level) {
			Entity entityToSpawn = new INFINITYBIPEDEntity(AvarstarsyModEntities.INFINITYBIPED.get(), _level);
			entityToSpawn.moveTo(x, y, z, world.getRandom().nextFloat() * 360F, 0);
			if (entityToSpawn instanceof Mob _mobToSpawn)
				_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
			world.addFreshEntity(entityToSpawn);
		}
	}
}
