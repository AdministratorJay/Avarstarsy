package net.mcreator.avarstarsy.procedures;

import net.minecraftforge.items.ItemHandlerHelper;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.GameType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.avarstarsy.init.AvarstarsyModItems;

import java.util.stream.Collectors;
import java.util.List;
import java.util.Comparator;

public class JProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player) {
			ItemStack _setstack = new ItemStack(AvarstarsyModItems.ENTITY_REMOVER.get());
			_setstack.setCount(1);
			ItemHandlerHelper.giveItemToPlayer(_player, _setstack);
		}
		{
			final Vec3 _center = new Vec3(x, y, z);
			List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(10000 / 2d), e -> true).stream()
					.sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).collect(Collectors.toList());
			for (Entity entityiterator : _entfound) {
				if (entityiterator instanceof Player _playerHasItem
						? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.ENTITY_REMOVER.get()))
						: false) {
					entityiterator.hurt(DamageSource.GENERIC, 0);
				} else {
					entityiterator.hurt(DamageSource.GENERIC, 2147483647);
					entityiterator.hurt(DamageSource.GENERIC, 2147483647);
					entityiterator.hurt(DamageSource.GENERIC, 2147483647);
					{
						Entity _ent = entityiterator;
						if (!_ent.level.isClientSide() && _ent.getServer() != null) {
							_ent.getServer().getCommands()
									.performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
											_ent.level instanceof ServerLevel ? (ServerLevel) _ent.level : null, 4, _ent.getName().getString(),
											_ent.getDisplayName(), _ent.level.getServer(), _ent), "clear");
						}
					}
					{
						Entity _ent = entityiterator;
						if (!_ent.level.isClientSide() && _ent.getServer() != null) {
							_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(),
									_ent.getRotationVector(), _ent.level instanceof ServerLevel ? (ServerLevel) _ent.level : null, 4,
									_ent.getName().getString(), _ent.getDisplayName(), _ent.level.getServer(), _ent), "say @s die for god");
						}
					}
					if (entityiterator instanceof Player _player) {
						_player.getAbilities().invulnerable = ((entityiterator instanceof LivingEntity _livEnt
								? _livEnt.getHealth()
								: -1) < Double.NEGATIVE_INFINITY);
						_player.onUpdateAbilities();
					}
					if (entityiterator instanceof ServerPlayer _player)
						_player.setGameMode(GameType.SURVIVAL);
					if (entityiterator instanceof Player _player)
						_player.getFoodData().setFoodLevel(0);
					if (entityiterator instanceof Player _player)
						_player.getFoodData().setSaturation(0);
					if (entityiterator instanceof Player _player)
						_player.causeFoodExhaustion(2147483647);
					entityiterator.setAirSupply(0);
					if (entityiterator instanceof LivingEntity _entity)
						_entity.setHealth(0);
					{
						Entity _ent = entityiterator;
						if (!_ent.level.isClientSide() && _ent.getServer() != null) {
							_ent.getServer().getCommands()
									.performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
											_ent.level instanceof ServerLevel ? (ServerLevel) _ent.level : null, 4, _ent.getName().getString(),
											_ent.getDisplayName(), _ent.level.getServer(), _ent), "kill");
						}
					}
					entityiterator.setSecondsOnFire((int) Double.POSITIVE_INFINITY);
					entityiterator.hurt(DamageSource.GENERIC, 2147483647);
					{
						Entity _ent = entityiterator;
						if (!_ent.level.isClientSide() && _ent.getServer() != null) {
							_ent.getServer().getCommands()
									.performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
											_ent.level instanceof ServerLevel ? (ServerLevel) _ent.level : null, 4, _ent.getName().getString(),
											_ent.getDisplayName(), _ent.level.getServer(), _ent), "clear");
						}
					}
					if (entityiterator instanceof Player _player) {
						_player.getAbilities().invulnerable = ((entityiterator instanceof LivingEntity _livEnt
								? _livEnt.getHealth()
								: -1) < Double.NEGATIVE_INFINITY);
						_player.onUpdateAbilities();
					}
					if (entityiterator instanceof ServerPlayer _player)
						_player.setGameMode(GameType.SURVIVAL);
					if (entityiterator instanceof Player _player)
						_player.getFoodData().setFoodLevel(0);
					if (entityiterator instanceof Player _player)
						_player.getFoodData().setSaturation(0);
					if (entityiterator instanceof Player _player)
						_player.causeFoodExhaustion((float) Double.POSITIVE_INFINITY);
					entityiterator.setAirSupply(0);
					if (entityiterator instanceof LivingEntity _entity)
						_entity.setHealth((float) Double.NEGATIVE_INFINITY);
					entityiterator.setSecondsOnFire((int) Double.POSITIVE_INFINITY);
					{
						Entity _ent = entityiterator;
						if (!_ent.level.isClientSide() && _ent.getServer() != null) {
							_ent.getServer().getCommands()
									.performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
											_ent.level instanceof ServerLevel ? (ServerLevel) _ent.level : null, 4, _ent.getName().getString(),
											_ent.getDisplayName(), _ent.level.getServer(), _ent), "kill");
						}
					}
					entityiterator.hurt(DamageSource.GENERIC, (float) Double.POSITIVE_INFINITY);
					entityiterator.hurt(DamageSource.OUT_OF_WORLD, (float) Double.POSITIVE_INFINITY);
					entityiterator.hurt(DamageSource.MAGIC, (float) Double.POSITIVE_INFINITY);
					entityiterator.hurt(DamageSource.WITHER, (float) Double.POSITIVE_INFINITY);
					if (entityiterator instanceof LivingEntity _entity)
						_entity.hurt(new DamageSource("").bypassArmor(), (float) Double.POSITIVE_INFINITY);
					entityiterator.setSecondsOnFire((int) Double.POSITIVE_INFINITY);
					entityiterator.hurt(DamageSource.GENERIC, entityiterator instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1);
					if (entityiterator instanceof LivingEntity _entity)
						_entity.setHealth(
								(float) ((entityiterator instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
					if (entityiterator instanceof LivingEntity _entity)
						_entity.setHealth(
								(float) ((entityiterator instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) + Double.POSITIVE_INFINITY));
					if (entityiterator instanceof LivingEntity _entity)
						_entity.hurt(new DamageSource("").bypassArmor(), entityiterator instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1);
					if (!entityiterator.level.isClientSide())
						entityiterator.discard();/*entity.world.removeEntity(entity);*/
					/*player.deathTime = 999999;*/
					/*player.ticksExisted = 999999;*/
					/*entity.updateBlocked = false;*/
					/*entity.onKillCommand();*/
					/*entity.onRemovedFromWorld();*/
					/*entity.onRemovedFromWorld();*/
					/*entity.world.removeEntity(entityiterator);*/
					/*entity.preventEntitySpawning = false;*/
					/*entity.setEntityInvulnerable(false);*/
					/*entity.setDead();*/
					/*entity.isDead = true;*/
					/*world.getChunk(entity.chunkCoordX, entity.chunkCoordZ).removeEntity(entity);*/
					/*world.loadedEntityList.remove(entity);entity.updateBlocked = true;*/
					/*entity.motionX = entity.motionY = entity.motionZ = 0;entity.lastTickPosX = entity.posX = entity.prevPosX = Double.NaN;entity.lastTickPosY = entity.posY = entity.prevPosY = Double.NaN;entity.lastTickPosZ = entity.posZ = entity.prevPosZ = Double.NaN;*/
					/*entity.noClip = true;entity.collided = entity.collidedVertically = entity.collidedHorizontally = false;entity.forceSpawn = false;entity.velocityChanged = true;*/
					/*entity.onUpdate();*/
				}
			}
		}
		if (entity instanceof Player _player) {
			ItemStack _stktoremove = new ItemStack(AvarstarsyModItems.ENTITY_REMOVER.get());
			_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
		}
	}
}
