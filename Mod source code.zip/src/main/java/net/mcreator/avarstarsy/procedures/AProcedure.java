package net.mcreator.avarstarsy.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.avarstarsy.entity.INFINITYBIPEDEntity;

public class AProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof LivingEntity _entity)
			_entity.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 1, (false), (false)));
		entity.clearFire();
		if (entity instanceof LivingEntity _entity)
			_entity.setHealth((float) Double.POSITIVE_INFINITY);
		if (entity instanceof Player _player) {
			_player.getAbilities().mayfly = (entity instanceof INFINITYBIPEDEntity);
			_player.onUpdateAbilities();
		}
		if (entity instanceof Player _player) {
			_player.getAbilities().mayBuild = (entity instanceof INFINITYBIPEDEntity);
			_player.onUpdateAbilities();
		}
		if (entity instanceof Player _player)
			_player.getFoodData().setFoodLevel((int) Double.POSITIVE_INFINITY);
		if (entity instanceof Player _player)
			_player.getFoodData().setSaturation((float) Double.POSITIVE_INFINITY);
		entity.setAirSupply(0);
		if (entity instanceof LivingEntity _entity)
			_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
		if (entity instanceof LivingEntity _entity)
			_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
					+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));/*player.isDead = false;*/
		/*player.deathTime = 0;*/
		/*player.ticksExisted = 0;*/
		/*GuiIngameForge.renderHealth = true;*/
		/*player.updateBlocked = false;*/
	}
}
