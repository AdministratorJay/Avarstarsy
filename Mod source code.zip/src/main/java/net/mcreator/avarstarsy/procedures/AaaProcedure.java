package net.mcreator.avarstarsy.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingAttackEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.avarstarsy.init.AvarstarsyModMobEffects;
import net.mcreator.avarstarsy.init.AvarstarsyModItems;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class AaaProcedure {
	@SubscribeEvent
	public static void onEntityAttacked(LivingAttackEvent event) {
		if (event != null && event.getEntity() != null) {
			execute(event, event.getEntity());
		}
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _playerHasItem
				? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_HELMET.get()))
				: false) {
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.DIG_SLOWDOWN);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.HEAL);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.CONFUSION);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.BLINDNESS);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.HUNGER);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.WEAKNESS);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.POISON);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.WITHER);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.GLOWING);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.LEVITATION);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.UNLUCK);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.DARKNESS);
			entity.clearFire();
			if (entity instanceof LivingEntity _entity)
				_entity.addEffect(new MobEffectInstance(MobEffects.HEALTH_BOOST, 180, 5, (false), (false)));
			if (entity instanceof LivingEntity _entity)
				_entity.addEffect(new MobEffectInstance(MobEffects.HEAL, 180, 2147483647, (false), (false)));
			if (entity instanceof LivingEntity _entity)
				_entity.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 1, (false), (false)));
			entity.clearFire();
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth((float) Double.POSITIVE_INFINITY);
			if (entity instanceof Player _player) {
				_player.getAbilities().mayfly = (entity instanceof Player _playerHasItem
						? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_HELMET.get()))
						: false);
				_player.onUpdateAbilities();
			}
			if (entity instanceof Player _player) {
				_player.getAbilities().mayBuild = (entity instanceof Player _playerHasItem
						? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_HELMET.get()))
						: false);
				_player.onUpdateAbilities();
			}
			if (entity instanceof Player _player)
				_player.getFoodData().setFoodLevel((int) Double.POSITIVE_INFINITY);
			if (entity instanceof Player _player)
				_player.getFoodData().setSaturation((float) Double.POSITIVE_INFINITY);
			entity.setAirSupply(0);
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
						+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));/*entity.isDead = false;*/
			/*entity.deathTime = 0;*/
			/*entity.ticksExisted = 0;*/
			/*GuiIngameForge.renderHealth = true;*/
			/*entity.updateBlocked = false;*/
			/*player.isDead = false;*/
			/*player.deathTime = 0;*/
			/*player.ticksExisted = 0;*/
			/*GuiIngameForge.renderHealth = true;*/
			/*player.updateBlocked = false;*/
			if (event != null && event.isCancelable()) {
				event.setCanceled(true);
			}
		} else {
			if (entity instanceof Player _playerHasItem
					? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_CHESTPLATE.get()))
					: false) {
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.DIG_SLOWDOWN);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.HEAL);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.CONFUSION);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.BLINDNESS);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.HUNGER);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.WEAKNESS);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.POISON);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.WITHER);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.GLOWING);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.LEVITATION);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.UNLUCK);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.DARKNESS);
				entity.clearFire();
				if (entity instanceof LivingEntity _entity)
					_entity.addEffect(new MobEffectInstance(MobEffects.HEALTH_BOOST, 180, 5, (false), (false)));
				if (entity instanceof LivingEntity _entity)
					_entity.addEffect(new MobEffectInstance(MobEffects.HEAL, 180, 2147483647, (false), (false)));
				if (entity instanceof LivingEntity _entity)
					_entity.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 1, (false), (false)));
				entity.clearFire();
				if (entity instanceof LivingEntity _entity)
					_entity.setHealth((float) Double.POSITIVE_INFINITY);
				if (entity instanceof Player _player) {
					_player.getAbilities().mayfly = (entity instanceof Player _playerHasItem
							? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_CHESTPLATE.get()))
							: false);
					_player.onUpdateAbilities();
				}
				if (entity instanceof Player _player) {
					_player.getAbilities().mayBuild = (entity instanceof Player _playerHasItem
							? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_CHESTPLATE.get()))
							: false);
					_player.onUpdateAbilities();
				}
				if (entity instanceof Player _player)
					_player.getFoodData().setFoodLevel((int) Double.POSITIVE_INFINITY);
				if (entity instanceof Player _player)
					_player.getFoodData().setSaturation((float) Double.POSITIVE_INFINITY);
				entity.setAirSupply(0);
				if (entity instanceof LivingEntity _entity)
					_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
				if (entity instanceof LivingEntity _entity)
					_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
							+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));/*entity.isDead = false;*/
				/*entity.deathTime = 0;*/
				/*entity.ticksExisted = 0;*/
				/*GuiIngameForge.renderHealth = true;*/
				/*entity.updateBlocked = false;*/
				/*player.isDead = false;*/
				/*player.deathTime = 0;*/
				/*player.ticksExisted = 0;*/
				/*GuiIngameForge.renderHealth = true;*/
				/*player.updateBlocked = false;*/
				if (event != null && event.isCancelable()) {
					event.setCanceled(true);
				}
			} else {
				if (entity instanceof Player _playerHasItem
						? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_LEGGINGS.get()))
						: false) {
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.DIG_SLOWDOWN);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.HEAL);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.CONFUSION);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.BLINDNESS);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.HUNGER);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.WEAKNESS);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.POISON);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.WITHER);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.GLOWING);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.LEVITATION);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.UNLUCK);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.DARKNESS);
					entity.clearFire();
					if (entity instanceof LivingEntity _entity)
						_entity.addEffect(new MobEffectInstance(MobEffects.HEALTH_BOOST, 180, 5, (false), (false)));
					if (entity instanceof LivingEntity _entity)
						_entity.addEffect(new MobEffectInstance(MobEffects.HEAL, 180, 2147483647, (false), (false)));
					if (entity instanceof LivingEntity _entity)
						_entity.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 1, (false), (false)));
					entity.clearFire();
					if (entity instanceof LivingEntity _entity)
						_entity.setHealth((float) Double.POSITIVE_INFINITY);
					if (entity instanceof Player _player) {
						_player.getAbilities().mayfly = (entity instanceof Player _playerHasItem
								? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_LEGGINGS.get()))
								: false);
						_player.onUpdateAbilities();
					}
					if (entity instanceof Player _player) {
						_player.getAbilities().mayBuild = (entity instanceof Player _playerHasItem
								? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_LEGGINGS.get()))
								: false);
						_player.onUpdateAbilities();
					}
					if (entity instanceof Player _player)
						_player.getFoodData().setFoodLevel((int) Double.POSITIVE_INFINITY);
					if (entity instanceof Player _player)
						_player.getFoodData().setSaturation((float) Double.POSITIVE_INFINITY);
					entity.setAirSupply(0);
					if (entity instanceof LivingEntity _entity)
						_entity.setHealth(
								(float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
					if (entity instanceof LivingEntity _entity)
						_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
								+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));/*entity.isDead = false;*/
					/*entity.deathTime = 0;*/
					/*entity.ticksExisted = 0;*/
					/*GuiIngameForge.renderHealth = true;*/
					/*entity.updateBlocked = false;*/
					/*player.isDead = false;*/
					/*player.deathTime = 0;*/
					/*player.ticksExisted = 0;*/
					/*GuiIngameForge.renderHealth = true;*/
					/*player.updateBlocked = false;*/
					if (event != null && event.isCancelable()) {
						event.setCanceled(true);
					}
				} else {
					if (entity instanceof Player _playerHasItem
							? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_BOOTS.get()))
							: false) {
						if (entity instanceof LivingEntity _entity)
							_entity.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
						if (entity instanceof LivingEntity _entity)
							_entity.removeEffect(MobEffects.DIG_SLOWDOWN);
						if (entity instanceof LivingEntity _entity)
							_entity.removeEffect(MobEffects.HEAL);
						if (entity instanceof LivingEntity _entity)
							_entity.removeEffect(MobEffects.CONFUSION);
						if (entity instanceof LivingEntity _entity)
							_entity.removeEffect(MobEffects.BLINDNESS);
						if (entity instanceof LivingEntity _entity)
							_entity.removeEffect(MobEffects.HUNGER);
						if (entity instanceof LivingEntity _entity)
							_entity.removeEffect(MobEffects.WEAKNESS);
						if (entity instanceof LivingEntity _entity)
							_entity.removeEffect(MobEffects.POISON);
						if (entity instanceof LivingEntity _entity)
							_entity.removeEffect(MobEffects.WITHER);
						if (entity instanceof LivingEntity _entity)
							_entity.removeEffect(MobEffects.GLOWING);
						if (entity instanceof LivingEntity _entity)
							_entity.removeEffect(MobEffects.LEVITATION);
						if (entity instanceof LivingEntity _entity)
							_entity.removeEffect(MobEffects.UNLUCK);
						if (entity instanceof LivingEntity _entity)
							_entity.removeEffect(MobEffects.DARKNESS);
						entity.clearFire();
						if (entity instanceof LivingEntity _entity)
							_entity.addEffect(new MobEffectInstance(MobEffects.HEALTH_BOOST, 180, 5, (false), (false)));
						if (entity instanceof LivingEntity _entity)
							_entity.addEffect(new MobEffectInstance(MobEffects.HEAL, 180, 2147483647, (false), (false)));
						if (entity instanceof LivingEntity _entity)
							_entity.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 1, (false), (false)));
						entity.clearFire();
						if (entity instanceof LivingEntity _entity)
							_entity.setHealth((float) Double.POSITIVE_INFINITY);
						if (entity instanceof Player _player) {
							_player.getAbilities().mayfly = (entity instanceof Player _playerHasItem
									? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_BOOTS.get()))
									: false);
							_player.onUpdateAbilities();
						}
						if (entity instanceof Player _player) {
							_player.getAbilities().mayBuild = (entity instanceof Player _playerHasItem
									? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_BOOTS.get()))
									: false);
							_player.onUpdateAbilities();
						}
						if (entity instanceof Player _player)
							_player.getFoodData().setFoodLevel((int) Double.POSITIVE_INFINITY);
						if (entity instanceof Player _player)
							_player.getFoodData().setSaturation((float) Double.POSITIVE_INFINITY);
						entity.setAirSupply(0);
						if (entity instanceof LivingEntity _entity)
							_entity.setHealth(
									(float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
						if (entity instanceof LivingEntity _entity)
							_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
									+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));/*entity.isDead = false;*/
						/*entity.deathTime = 0;*/
						/*entity.ticksExisted = 0;*/
						/*GuiIngameForge.renderHealth = true;*/
						/*entity.updateBlocked = false;*/
						/*player.isDead = false;*/
						/*player.deathTime = 0;*/
						/*player.ticksExisted = 0;*/
						/*GuiIngameForge.renderHealth = true;*/
						/*player.updateBlocked = false;*/
						if (event != null && event.isCancelable()) {
							event.setCanceled(true);
						}
					} else {
						if (entity instanceof Player _playerHasItem
								? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.ENTITY_REMOVER.get()))
								: false) {
							entity.canUpdate(true);
							if (entity instanceof LivingEntity _entity)
								_entity.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
							if (entity instanceof LivingEntity _entity)
								_entity.removeEffect(MobEffects.DIG_SLOWDOWN);
							if (entity instanceof LivingEntity _entity)
								_entity.removeEffect(MobEffects.HEAL);
							if (entity instanceof LivingEntity _entity)
								_entity.removeEffect(MobEffects.CONFUSION);
							if (entity instanceof LivingEntity _entity)
								_entity.removeEffect(MobEffects.BLINDNESS);
							if (entity instanceof LivingEntity _entity)
								_entity.removeEffect(MobEffects.HUNGER);
							if (entity instanceof LivingEntity _entity)
								_entity.removeEffect(MobEffects.WEAKNESS);
							if (entity instanceof LivingEntity _entity)
								_entity.removeEffect(MobEffects.POISON);
							if (entity instanceof LivingEntity _entity)
								_entity.removeEffect(MobEffects.WITHER);
							if (entity instanceof LivingEntity _entity)
								_entity.removeEffect(MobEffects.GLOWING);
							if (entity instanceof LivingEntity _entity)
								_entity.removeEffect(MobEffects.LEVITATION);
							if (entity instanceof LivingEntity _entity)
								_entity.removeEffect(MobEffects.UNLUCK);
							if (entity instanceof LivingEntity _entity)
								_entity.removeEffect(MobEffects.DARKNESS);
							entity.clearFire();
							if (entity instanceof LivingEntity _entity)
								_entity.addEffect(new MobEffectInstance(MobEffects.HEALTH_BOOST, 180, 5, (false), (false)));
							if (entity instanceof LivingEntity _entity)
								_entity.addEffect(new MobEffectInstance(MobEffects.HEAL, 180, 2147483647, (false), (false)));
							if (entity instanceof LivingEntity _entity)
								_entity.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 1, (false), (false)));
							entity.clearFire();
							if (entity instanceof LivingEntity _entity)
								_entity.setHealth((float) Double.POSITIVE_INFINITY);
							if (entity instanceof Player _player) {
								_player.getAbilities().mayfly = (entity instanceof Player _playerHasItem
										? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.ENTITY_REMOVER.get()))
										: false);
								_player.onUpdateAbilities();
							}
							if (entity instanceof Player _player) {
								_player.getAbilities().mayBuild = (entity instanceof Player _playerHasItem
										? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.ENTITY_REMOVER.get()))
										: false);
								_player.onUpdateAbilities();
							}
							if (entity instanceof Player _player)
								_player.getFoodData().setFoodLevel((int) Double.POSITIVE_INFINITY);
							if (entity instanceof Player _player)
								_player.getFoodData().setSaturation((float) Double.POSITIVE_INFINITY);
							entity.setAirSupply(0);
							if (entity instanceof LivingEntity _entity)
								_entity.setHealth(
										(float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
							if (entity instanceof LivingEntity _entity)
								_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
										+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));/*entity.isDead = false;*/
							/*entity.deathTime = 0;*/
							/*entity.ticksExisted = 0;*/
							/*GuiIngameForge.renderHealth = true;*/
							/*entity.updateBlocked = false;*/
							/*player.isDead = false;*/
							/*player.deathTime = 0;*/
							/*player.ticksExisted = 0;*/
							/*GuiIngameForge.renderHealth = true;*/
							/*player.updateBlocked = false;*/
							if (event != null && event.isCancelable()) {
								event.setCanceled(true);
							}
						} else {
							if ((entity instanceof LivingEntity _livEnt
									? _livEnt.hasEffect(AvarstarsyModMobEffects.INVINCIBLE.get())
									: false) == true) {
								if (entity instanceof LivingEntity _entity)
									_entity.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
								if (entity instanceof LivingEntity _entity)
									_entity.removeEffect(MobEffects.DIG_SLOWDOWN);
								if (entity instanceof LivingEntity _entity)
									_entity.removeEffect(MobEffects.HEAL);
								if (entity instanceof LivingEntity _entity)
									_entity.removeEffect(MobEffects.CONFUSION);
								if (entity instanceof LivingEntity _entity)
									_entity.removeEffect(MobEffects.BLINDNESS);
								if (entity instanceof LivingEntity _entity)
									_entity.removeEffect(MobEffects.HUNGER);
								if (entity instanceof LivingEntity _entity)
									_entity.removeEffect(MobEffects.WEAKNESS);
								if (entity instanceof LivingEntity _entity)
									_entity.removeEffect(MobEffects.POISON);
								if (entity instanceof LivingEntity _entity)
									_entity.removeEffect(MobEffects.WITHER);
								if (entity instanceof LivingEntity _entity)
									_entity.removeEffect(MobEffects.GLOWING);
								if (entity instanceof LivingEntity _entity)
									_entity.removeEffect(MobEffects.LEVITATION);
								if (entity instanceof LivingEntity _entity)
									_entity.removeEffect(MobEffects.UNLUCK);
								if (entity instanceof LivingEntity _entity)
									_entity.removeEffect(MobEffects.DARKNESS);
								entity.clearFire();
								if (entity instanceof LivingEntity _entity)
									_entity.addEffect(new MobEffectInstance(MobEffects.HEALTH_BOOST, 180, 5, (false), (false)));
								if (entity instanceof LivingEntity _entity)
									_entity.addEffect(new MobEffectInstance(MobEffects.HEAL, 180, 2147483647, (false), (false)));
								if (entity instanceof LivingEntity _entity)
									_entity.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 1, (false), (false)));
								entity.clearFire();
								if (entity instanceof LivingEntity _entity)
									_entity.setHealth((float) Double.POSITIVE_INFINITY);
								if (entity instanceof Player _player)
									_player.getFoodData().setFoodLevel((int) Double.POSITIVE_INFINITY);
								if (entity instanceof Player _player)
									_player.getFoodData().setSaturation((float) Double.POSITIVE_INFINITY);
								entity.setAirSupply(0);
								if (entity instanceof LivingEntity _entity)
									_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
											+ Double.POSITIVE_INFINITY));
								if (entity instanceof LivingEntity _entity)
									_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
											+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));/*entity.isDead = false;*/
								/*entity.deathTime = 0;*/
								/*entity.ticksExisted = 0;*/
								/*GuiIngameForge.renderHealth = true;*/
								/*entity.updateBlocked = false;*/
								/*player.isDead = false;*/
								/*player.deathTime = 0;*/
								/*player.ticksExisted = 0;*/
								/*GuiIngameForge.renderHealth = true;*/
								/*player.updateBlocked = false;*/
								if (event != null && event.isCancelable()) {
									event.setCanceled(true);
								}
							}
						}
					}
				}
			}
		}
	}
}
