package net.mcreator.avarstarsy.procedures;

import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingDeathEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.MenuProvider;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.core.BlockPos;

import net.mcreator.avarstarsy.world.inventory.EmptyMenu;
import net.mcreator.avarstarsy.init.AvarstarsyModMobEffects;
import net.mcreator.avarstarsy.init.AvarstarsyModItems;

import javax.annotation.Nullable;

import io.netty.buffer.Unpooled;

@Mod.EventBusSubscriber
public class AaaaProcedure {
	@SubscribeEvent
	public static void onEntityDeath(LivingDeathEvent event) {
		if (event != null && event.getEntity() != null) {
			execute(event, event.getEntity().level, event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity());
		}
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _playerHasItem
				? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_HELMET.get()))
				: false) {
			if (event != null && event.isCancelable()) {
				event.setCanceled(true);
			}
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
						+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));
			if (entity instanceof Player _player)
				_player.closeContainer();
			if (entity instanceof Player _player)
				_player.closeContainer();
			if (entity instanceof Player _player)
				_player.closeContainer();
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
						+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));
			if (entity instanceof Player _player)
				_player.closeContainer();
			if (entity instanceof Player _player)
				_player.closeContainer();
			if (entity instanceof Player _player)
				_player.closeContainer();
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
						+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));
			{
				if (entity instanceof ServerPlayer _ent) {
					BlockPos _bpos = new BlockPos(x, y, z);
					NetworkHooks.openScreen((ServerPlayer) _ent, new MenuProvider() {
						@Override
						public Component getDisplayName() {
							return Component.literal("Empty");
						}

						@Override
						public AbstractContainerMenu createMenu(int id, Inventory inventory, Player player) {
							return new EmptyMenu(id, inventory, new FriendlyByteBuf(Unpooled.buffer()).writeBlockPos(_bpos));
						}
					}, _bpos);
				}
			}
			if (entity instanceof Player _player)
				_player.closeContainer();
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.DIG_SLOWDOWN);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.HEAL);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.CONFUSION);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.BLINDNESS);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.HUNGER);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.WEAKNESS);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.POISON);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.WITHER);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.GLOWING);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.LEVITATION);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.UNLUCK);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.DARKNESS);
			entity.clearFire();
			if (entity instanceof LivingEntity _entity)
				_entity.addEffect(new MobEffectInstance(MobEffects.HEALTH_BOOST, 180, 5, (false), (false)));
			if (entity instanceof LivingEntity _entity)
				_entity.addEffect(new MobEffectInstance(MobEffects.HEAL, 180, 2147483647, (false), (false)));
			if (entity instanceof LivingEntity _entity)
				_entity.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 1, (false), (false)));
			entity.clearFire();
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth((float) Double.POSITIVE_INFINITY);
			if (entity instanceof Player _player) {
				_player.getAbilities().mayfly = (entity instanceof Player _playerHasItem
						? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_HELMET.get()))
						: false);
				_player.onUpdateAbilities();
			}
			if (entity instanceof Player _player) {
				_player.getAbilities().mayBuild = (entity instanceof Player _playerHasItem
						? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_HELMET.get()))
						: false);
				_player.onUpdateAbilities();
			}
			if (entity instanceof Player _player)
				_player.getFoodData().setFoodLevel((int) Double.POSITIVE_INFINITY);
			if (entity instanceof Player _player)
				_player.getFoodData().setSaturation((float) Double.POSITIVE_INFINITY);
			entity.setAirSupply(0);
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
						+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));/*entity.isDead = false;*/
			/*entity.deathTime = 0;*/
			/*entity.ticksExisted = 0;*/
			/*GuiIngameForge.renderHealth = true;*/
			/*entity.updateBlocked = false;*/
			/*player.isDead = false;*/
			/*player.deathTime = 0;*/
			/*player.ticksExisted = 0;*/
			/*GuiIngameForge.renderHealth = true;*/
			/*player.updateBlocked = false;*/
			if (event != null && event.isCancelable()) {
				event.setCanceled(true);
			}
		} else {
			if (entity instanceof Player _playerHasItem
					? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_CHESTPLATE.get()))
					: false) {
				if (event != null && event.isCancelable()) {
					event.setCanceled(true);
				}
				if (entity instanceof LivingEntity _entity)
					_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
				if (entity instanceof LivingEntity _entity)
					_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
							+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));
				if (entity instanceof Player _player)
					_player.closeContainer();
				if (entity instanceof Player _player)
					_player.closeContainer();
				if (entity instanceof Player _player)
					_player.closeContainer();
				if (entity instanceof LivingEntity _entity)
					_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
				if (entity instanceof LivingEntity _entity)
					_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
							+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));
				if (entity instanceof Player _player)
					_player.closeContainer();
				if (entity instanceof Player _player)
					_player.closeContainer();
				if (entity instanceof Player _player)
					_player.closeContainer();
				if (entity instanceof LivingEntity _entity)
					_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
				if (entity instanceof LivingEntity _entity)
					_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
							+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));
				{
					if (entity instanceof ServerPlayer _ent) {
						BlockPos _bpos = new BlockPos(x, y, z);
						NetworkHooks.openScreen((ServerPlayer) _ent, new MenuProvider() {
							@Override
							public Component getDisplayName() {
								return Component.literal("Empty");
							}

							@Override
							public AbstractContainerMenu createMenu(int id, Inventory inventory, Player player) {
								return new EmptyMenu(id, inventory, new FriendlyByteBuf(Unpooled.buffer()).writeBlockPos(_bpos));
							}
						}, _bpos);
					}
				}
				if (entity instanceof Player _player)
					_player.closeContainer();
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.DIG_SLOWDOWN);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.HEAL);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.CONFUSION);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.BLINDNESS);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.HUNGER);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.WEAKNESS);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.POISON);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.WITHER);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.GLOWING);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.LEVITATION);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.UNLUCK);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.DARKNESS);
				entity.clearFire();
				if (entity instanceof LivingEntity _entity)
					_entity.addEffect(new MobEffectInstance(MobEffects.HEALTH_BOOST, 180, 5, (false), (false)));
				if (entity instanceof LivingEntity _entity)
					_entity.addEffect(new MobEffectInstance(MobEffects.HEAL, 180, 2147483647, (false), (false)));
				if (entity instanceof LivingEntity _entity)
					_entity.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 1, (false), (false)));
				entity.clearFire();
				if (entity instanceof LivingEntity _entity)
					_entity.setHealth((float) Double.POSITIVE_INFINITY);
				if (entity instanceof Player _player) {
					_player.getAbilities().mayfly = (entity instanceof Player _playerHasItem
							? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_CHESTPLATE.get()))
							: false);
					_player.onUpdateAbilities();
				}
				if (entity instanceof Player _player) {
					_player.getAbilities().mayBuild = (entity instanceof Player _playerHasItem
							? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_CHESTPLATE.get()))
							: false);
					_player.onUpdateAbilities();
				}
				if (entity instanceof Player _player)
					_player.getFoodData().setFoodLevel((int) Double.POSITIVE_INFINITY);
				if (entity instanceof Player _player)
					_player.getFoodData().setSaturation((float) Double.POSITIVE_INFINITY);
				entity.setAirSupply(0);
				if (entity instanceof LivingEntity _entity)
					_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
				if (entity instanceof LivingEntity _entity)
					_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
							+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));/*entity.isDead = false;*/
				/*entity.deathTime = 0;*/
				/*entity.ticksExisted = 0;*/
				/*GuiIngameForge.renderHealth = true;*/
				/*entity.updateBlocked = false;*/
				/*player.isDead = false;*/
				/*player.deathTime = 0;*/
				/*player.ticksExisted = 0;*/
				/*GuiIngameForge.renderHealth = true;*/
				/*player.updateBlocked = false;*/
				if (event != null && event.isCancelable()) {
					event.setCanceled(true);
				}
			} else {
				if (entity instanceof Player _playerHasItem
						? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_LEGGINGS.get()))
						: false) {
					if (event != null && event.isCancelable()) {
						event.setCanceled(true);
					}
					if (entity instanceof LivingEntity _entity)
						_entity.setHealth(
								(float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
					if (entity instanceof LivingEntity _entity)
						_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
								+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));
					if (entity instanceof Player _player)
						_player.closeContainer();
					if (entity instanceof Player _player)
						_player.closeContainer();
					if (entity instanceof Player _player)
						_player.closeContainer();
					if (entity instanceof LivingEntity _entity)
						_entity.setHealth(
								(float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
					if (entity instanceof LivingEntity _entity)
						_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
								+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));
					if (entity instanceof Player _player)
						_player.closeContainer();
					if (entity instanceof Player _player)
						_player.closeContainer();
					if (entity instanceof Player _player)
						_player.closeContainer();
					if (entity instanceof LivingEntity _entity)
						_entity.setHealth(
								(float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
					if (entity instanceof LivingEntity _entity)
						_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
								+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));
					{
						if (entity instanceof ServerPlayer _ent) {
							BlockPos _bpos = new BlockPos(x, y, z);
							NetworkHooks.openScreen((ServerPlayer) _ent, new MenuProvider() {
								@Override
								public Component getDisplayName() {
									return Component.literal("Empty");
								}

								@Override
								public AbstractContainerMenu createMenu(int id, Inventory inventory, Player player) {
									return new EmptyMenu(id, inventory, new FriendlyByteBuf(Unpooled.buffer()).writeBlockPos(_bpos));
								}
							}, _bpos);
						}
					}
					if (entity instanceof Player _player)
						_player.closeContainer();
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.DIG_SLOWDOWN);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.HEAL);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.CONFUSION);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.BLINDNESS);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.HUNGER);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.WEAKNESS);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.POISON);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.WITHER);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.GLOWING);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.LEVITATION);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.UNLUCK);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.DARKNESS);
					entity.clearFire();
					if (entity instanceof LivingEntity _entity)
						_entity.addEffect(new MobEffectInstance(MobEffects.HEALTH_BOOST, 180, 5, (false), (false)));
					if (entity instanceof LivingEntity _entity)
						_entity.addEffect(new MobEffectInstance(MobEffects.HEAL, 180, 2147483647, (false), (false)));
					if (entity instanceof LivingEntity _entity)
						_entity.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 1, (false), (false)));
					entity.clearFire();
					if (entity instanceof LivingEntity _entity)
						_entity.setHealth((float) Double.POSITIVE_INFINITY);
					if (entity instanceof Player _player) {
						_player.getAbilities().mayfly = (entity instanceof Player _playerHasItem
								? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_LEGGINGS.get()))
								: false);
						_player.onUpdateAbilities();
					}
					if (entity instanceof Player _player) {
						_player.getAbilities().mayBuild = (entity instanceof Player _playerHasItem
								? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_LEGGINGS.get()))
								: false);
						_player.onUpdateAbilities();
					}
					if (entity instanceof Player _player)
						_player.getFoodData().setFoodLevel((int) Double.POSITIVE_INFINITY);
					if (entity instanceof Player _player)
						_player.getFoodData().setSaturation((float) Double.POSITIVE_INFINITY);
					entity.setAirSupply(0);
					if (entity instanceof LivingEntity _entity)
						_entity.setHealth(
								(float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
					if (entity instanceof LivingEntity _entity)
						_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
								+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));/*entity.isDead = false;*/
					/*entity.deathTime = 0;*/
					/*entity.ticksExisted = 0;*/
					/*GuiIngameForge.renderHealth = true;*/
					/*entity.updateBlocked = false;*/
					/*player.isDead = false;*/
					/*player.deathTime = 0;*/
					/*player.ticksExisted = 0;*/
					/*GuiIngameForge.renderHealth = true;*/
					/*player.updateBlocked = false;*/
					if (event != null && event.isCancelable()) {
						event.setCanceled(true);
					}
				} else {
					if (entity instanceof Player _playerHasItem
							? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_BOOTS.get()))
							: false) {
						if (event != null && event.isCancelable()) {
							event.setCanceled(true);
						}
						if (entity instanceof LivingEntity _entity)
							_entity.setHealth(
									(float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
						if (entity instanceof LivingEntity _entity)
							_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
									+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));
						if (entity instanceof Player _player)
							_player.closeContainer();
						if (entity instanceof Player _player)
							_player.closeContainer();
						if (entity instanceof Player _player)
							_player.closeContainer();
						if (entity instanceof LivingEntity _entity)
							_entity.setHealth(
									(float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
						if (entity instanceof LivingEntity _entity)
							_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
									+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));
						if (entity instanceof Player _player)
							_player.closeContainer();
						if (entity instanceof Player _player)
							_player.closeContainer();
						if (entity instanceof Player _player)
							_player.closeContainer();
						if (entity instanceof LivingEntity _entity)
							_entity.setHealth(
									(float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
						if (entity instanceof LivingEntity _entity)
							_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
									+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));
						{
							if (entity instanceof ServerPlayer _ent) {
								BlockPos _bpos = new BlockPos(x, y, z);
								NetworkHooks.openScreen((ServerPlayer) _ent, new MenuProvider() {
									@Override
									public Component getDisplayName() {
										return Component.literal("Empty");
									}

									@Override
									public AbstractContainerMenu createMenu(int id, Inventory inventory, Player player) {
										return new EmptyMenu(id, inventory, new FriendlyByteBuf(Unpooled.buffer()).writeBlockPos(_bpos));
									}
								}, _bpos);
							}
						}
						if (entity instanceof Player _player)
							_player.closeContainer();
						if (entity instanceof LivingEntity _entity)
							_entity.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
						if (entity instanceof LivingEntity _entity)
							_entity.removeEffect(MobEffects.DIG_SLOWDOWN);
						if (entity instanceof LivingEntity _entity)
							_entity.removeEffect(MobEffects.HEAL);
						if (entity instanceof LivingEntity _entity)
							_entity.removeEffect(MobEffects.CONFUSION);
						if (entity instanceof LivingEntity _entity)
							_entity.removeEffect(MobEffects.BLINDNESS);
						if (entity instanceof LivingEntity _entity)
							_entity.removeEffect(MobEffects.HUNGER);
						if (entity instanceof LivingEntity _entity)
							_entity.removeEffect(MobEffects.WEAKNESS);
						if (entity instanceof LivingEntity _entity)
							_entity.removeEffect(MobEffects.POISON);
						if (entity instanceof LivingEntity _entity)
							_entity.removeEffect(MobEffects.WITHER);
						if (entity instanceof LivingEntity _entity)
							_entity.removeEffect(MobEffects.GLOWING);
						if (entity instanceof LivingEntity _entity)
							_entity.removeEffect(MobEffects.LEVITATION);
						if (entity instanceof LivingEntity _entity)
							_entity.removeEffect(MobEffects.UNLUCK);
						if (entity instanceof LivingEntity _entity)
							_entity.removeEffect(MobEffects.DARKNESS);
						entity.clearFire();
						if (entity instanceof LivingEntity _entity)
							_entity.addEffect(new MobEffectInstance(MobEffects.HEALTH_BOOST, 180, 5, (false), (false)));
						if (entity instanceof LivingEntity _entity)
							_entity.addEffect(new MobEffectInstance(MobEffects.HEAL, 180, 2147483647, (false), (false)));
						if (entity instanceof LivingEntity _entity)
							_entity.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 1, (false), (false)));
						entity.clearFire();
						if (entity instanceof LivingEntity _entity)
							_entity.setHealth((float) Double.POSITIVE_INFINITY);
						if (entity instanceof Player _player) {
							_player.getAbilities().mayfly = (entity instanceof Player _playerHasItem
									? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_BOOTS.get()))
									: false);
							_player.onUpdateAbilities();
						}
						if (entity instanceof Player _player) {
							_player.getAbilities().mayBuild = (entity instanceof Player _playerHasItem
									? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_BOOTS.get()))
									: false);
							_player.onUpdateAbilities();
						}
						if (entity instanceof Player _player)
							_player.getFoodData().setFoodLevel((int) Double.POSITIVE_INFINITY);
						if (entity instanceof Player _player)
							_player.getFoodData().setSaturation((float) Double.POSITIVE_INFINITY);
						entity.setAirSupply(0);
						if (entity instanceof LivingEntity _entity)
							_entity.setHealth(
									(float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
						if (entity instanceof LivingEntity _entity)
							_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
									+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));/*entity.isDead = false;*/
						/*entity.deathTime = 0;*/
						/*entity.ticksExisted = 0;*/
						/*GuiIngameForge.renderHealth = true;*/
						/*entity.updateBlocked = false;*/
						/*player.isDead = false;*/
						/*player.deathTime = 0;*/
						/*player.ticksExisted = 0;*/
						/*GuiIngameForge.renderHealth = true;*/
						/*player.updateBlocked = false;*/
						if (event != null && event.isCancelable()) {
							event.setCanceled(true);
						}
					} else {
						if (entity instanceof Player _playerHasItem
								? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.ENTITY_REMOVER.get()))
								: false) {
							if (event != null && event.isCancelable()) {
								event.setCanceled(true);
							}
							entity.canUpdate(true);
							if (entity instanceof LivingEntity _entity)
								_entity.setHealth(
										(float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
							if (entity instanceof LivingEntity _entity)
								_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
										+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));
							if (entity instanceof Player _player)
								_player.closeContainer();
							if (entity instanceof Player _player)
								_player.closeContainer();
							if (entity instanceof Player _player)
								_player.closeContainer();
							if (entity instanceof LivingEntity _entity)
								_entity.setHealth(
										(float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
							if (entity instanceof LivingEntity _entity)
								_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
										+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));
							if (entity instanceof Player _player)
								_player.closeContainer();
							if (entity instanceof Player _player)
								_player.closeContainer();
							if (entity instanceof Player _player)
								_player.closeContainer();
							if (entity instanceof LivingEntity _entity)
								_entity.setHealth(
										(float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
							if (entity instanceof LivingEntity _entity)
								_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
										+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));
							{
								if (entity instanceof ServerPlayer _ent) {
									BlockPos _bpos = new BlockPos(x, y, z);
									NetworkHooks.openScreen((ServerPlayer) _ent, new MenuProvider() {
										@Override
										public Component getDisplayName() {
											return Component.literal("Empty");
										}

										@Override
										public AbstractContainerMenu createMenu(int id, Inventory inventory, Player player) {
											return new EmptyMenu(id, inventory, new FriendlyByteBuf(Unpooled.buffer()).writeBlockPos(_bpos));
										}
									}, _bpos);
								}
							}
							if (entity instanceof Player _player)
								_player.closeContainer();
							if (entity instanceof LivingEntity _entity)
								_entity.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
							if (entity instanceof LivingEntity _entity)
								_entity.removeEffect(MobEffects.DIG_SLOWDOWN);
							if (entity instanceof LivingEntity _entity)
								_entity.removeEffect(MobEffects.HEAL);
							if (entity instanceof LivingEntity _entity)
								_entity.removeEffect(MobEffects.CONFUSION);
							if (entity instanceof LivingEntity _entity)
								_entity.removeEffect(MobEffects.BLINDNESS);
							if (entity instanceof LivingEntity _entity)
								_entity.removeEffect(MobEffects.HUNGER);
							if (entity instanceof LivingEntity _entity)
								_entity.removeEffect(MobEffects.WEAKNESS);
							if (entity instanceof LivingEntity _entity)
								_entity.removeEffect(MobEffects.POISON);
							if (entity instanceof LivingEntity _entity)
								_entity.removeEffect(MobEffects.WITHER);
							if (entity instanceof LivingEntity _entity)
								_entity.removeEffect(MobEffects.GLOWING);
							if (entity instanceof LivingEntity _entity)
								_entity.removeEffect(MobEffects.LEVITATION);
							if (entity instanceof LivingEntity _entity)
								_entity.removeEffect(MobEffects.UNLUCK);
							if (entity instanceof LivingEntity _entity)
								_entity.removeEffect(MobEffects.DARKNESS);
							entity.clearFire();
							if (entity instanceof LivingEntity _entity)
								_entity.addEffect(new MobEffectInstance(MobEffects.HEALTH_BOOST, 180, 5, (false), (false)));
							if (entity instanceof LivingEntity _entity)
								_entity.addEffect(new MobEffectInstance(MobEffects.HEAL, 180, 2147483647, (false), (false)));
							if (entity instanceof LivingEntity _entity)
								_entity.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 1, (false), (false)));
							entity.clearFire();
							if (entity instanceof LivingEntity _entity)
								_entity.setHealth((float) Double.POSITIVE_INFINITY);
							if (entity instanceof Player _player) {
								_player.getAbilities().mayfly = (entity instanceof Player _playerHasItem
										? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.ENTITY_REMOVER.get()))
										: false);
								_player.onUpdateAbilities();
							}
							if (entity instanceof Player _player) {
								_player.getAbilities().mayBuild = (entity instanceof Player _playerHasItem
										? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.ENTITY_REMOVER.get()))
										: false);
								_player.onUpdateAbilities();
							}
							if (entity instanceof Player _player)
								_player.getFoodData().setFoodLevel((int) Double.POSITIVE_INFINITY);
							if (entity instanceof Player _player)
								_player.getFoodData().setSaturation((float) Double.POSITIVE_INFINITY);
							entity.setAirSupply(0);
							if (entity instanceof LivingEntity _entity)
								_entity.setHealth(
										(float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
							if (entity instanceof LivingEntity _entity)
								_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
										+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));/*entity.isDead = false;*/
							/*entity.deathTime = 0;*/
							/*entity.ticksExisted = 0;*/
							/*GuiIngameForge.renderHealth = true;*/
							/*entity.updateBlocked = false;*/
							/*player.isDead = false;*/
							/*player.deathTime = 0;*/
							/*player.ticksExisted = 0;*/
							/*GuiIngameForge.renderHealth = true;*/
							/*player.updateBlocked = false;*/
							if (event != null && event.isCancelable()) {
								event.setCanceled(true);
							}
						} else {
							if ((entity instanceof LivingEntity _livEnt
									? _livEnt.hasEffect(AvarstarsyModMobEffects.INVINCIBLE.get())
									: false) == true) {
								if (event != null && event.isCancelable()) {
									event.setCanceled(true);
								}
								if (entity instanceof LivingEntity _entity)
									_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
											+ Double.POSITIVE_INFINITY));
								if (entity instanceof LivingEntity _entity)
									_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
											+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));
								if (entity instanceof Player _player)
									_player.closeContainer();
								if (entity instanceof Player _player)
									_player.closeContainer();
								if (entity instanceof Player _player)
									_player.closeContainer();
								if (entity instanceof LivingEntity _entity)
									_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
											+ Double.POSITIVE_INFINITY));
								if (entity instanceof LivingEntity _entity)
									_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
											+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));
								if (entity instanceof Player _player)
									_player.closeContainer();
								if (entity instanceof Player _player)
									_player.closeContainer();
								if (entity instanceof Player _player)
									_player.closeContainer();
								if (entity instanceof LivingEntity _entity)
									_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
											+ Double.POSITIVE_INFINITY));
								if (entity instanceof LivingEntity _entity)
									_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
											+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));
								{
									if (entity instanceof ServerPlayer _ent) {
										BlockPos _bpos = new BlockPos(x, y, z);
										NetworkHooks.openScreen((ServerPlayer) _ent, new MenuProvider() {
											@Override
											public Component getDisplayName() {
												return Component.literal("Empty");
											}

											@Override
											public AbstractContainerMenu createMenu(int id, Inventory inventory, Player player) {
												return new EmptyMenu(id, inventory, new FriendlyByteBuf(Unpooled.buffer()).writeBlockPos(_bpos));
											}
										}, _bpos);
									}
								}
								if (entity instanceof Player _player)
									_player.closeContainer();
								if (entity instanceof LivingEntity _entity)
									_entity.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
								if (entity instanceof LivingEntity _entity)
									_entity.removeEffect(MobEffects.DIG_SLOWDOWN);
								if (entity instanceof LivingEntity _entity)
									_entity.removeEffect(MobEffects.HEAL);
								if (entity instanceof LivingEntity _entity)
									_entity.removeEffect(MobEffects.CONFUSION);
								if (entity instanceof LivingEntity _entity)
									_entity.removeEffect(MobEffects.BLINDNESS);
								if (entity instanceof LivingEntity _entity)
									_entity.removeEffect(MobEffects.HUNGER);
								if (entity instanceof LivingEntity _entity)
									_entity.removeEffect(MobEffects.WEAKNESS);
								if (entity instanceof LivingEntity _entity)
									_entity.removeEffect(MobEffects.POISON);
								if (entity instanceof LivingEntity _entity)
									_entity.removeEffect(MobEffects.WITHER);
								if (entity instanceof LivingEntity _entity)
									_entity.removeEffect(MobEffects.GLOWING);
								if (entity instanceof LivingEntity _entity)
									_entity.removeEffect(MobEffects.LEVITATION);
								if (entity instanceof LivingEntity _entity)
									_entity.removeEffect(MobEffects.UNLUCK);
								if (entity instanceof LivingEntity _entity)
									_entity.removeEffect(MobEffects.DARKNESS);
								entity.clearFire();
								if (entity instanceof LivingEntity _entity)
									_entity.addEffect(new MobEffectInstance(MobEffects.HEALTH_BOOST, 180, 5, (false), (false)));
								if (entity instanceof LivingEntity _entity)
									_entity.addEffect(new MobEffectInstance(MobEffects.HEAL, 180, 2147483647, (false), (false)));
								if (entity instanceof LivingEntity _entity)
									_entity.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 1, (false), (false)));
								entity.clearFire();
								if (entity instanceof LivingEntity _entity)
									_entity.setHealth((float) Double.POSITIVE_INFINITY);
								if (entity instanceof Player _player)
									_player.getFoodData().setFoodLevel((int) Double.POSITIVE_INFINITY);
								if (entity instanceof Player _player)
									_player.getFoodData().setSaturation((float) Double.POSITIVE_INFINITY);
								entity.setAirSupply(0);
								if (entity instanceof LivingEntity _entity)
									_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
											+ Double.POSITIVE_INFINITY));
								if (entity instanceof LivingEntity _entity)
									_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
											+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));/*entity.isDead = false;*/
								/*entity.deathTime = 0;*/
								/*entity.ticksExisted = 0;*/
								/*GuiIngameForge.renderHealth = true;*/
								/*entity.updateBlocked = false;*/
								/*player.isDead = false;*/
								/*player.deathTime = 0;*/
								/*player.ticksExisted = 0;*/
								/*GuiIngameForge.renderHealth = true;*/
								/*player.updateBlocked = false;*/
								if (event != null && event.isCancelable()) {
									event.setCanceled(true);
								}
							}
						}
					}
				}
			}
		}
	}
}
