package net.mcreator.avarstarsy.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.projectile.ThrownExperienceBottle;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.util.RandomSource;

import net.mcreator.avarstarsy.init.AvarstarsyModItems;
import net.mcreator.avarstarsy.entity.INFINITYBIPEDEntity;

import java.util.stream.Collectors;
import java.util.List;
import java.util.Comparator;

public class KillProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		{
			final Vec3 _center = new Vec3(x, y, z);
			List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(4 / 2d), e -> true).stream()
					.sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).collect(Collectors.toList());
			for (Entity entityiterator : _entfound) {
				if (entityiterator instanceof Player _playerHasItem
						? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_SWORD.get()))
						: false) {
					entityiterator.hurt(DamageSource.GENERIC, 0);
				} else {
					if (entityiterator instanceof Player _playerHasItem
							? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_HELMET.get()))
							: false) {
						entityiterator.hurt(DamageSource.GENERIC, 0);
					} else {
						if (entityiterator instanceof Player _playerHasItem
								? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_CHESTPLATE.get()))
								: false) {
							entityiterator.hurt(DamageSource.GENERIC, 0);
						} else {
							if (entityiterator instanceof Player _playerHasItem
									? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_LEGGINGS.get()))
									: false) {
								entityiterator.hurt(DamageSource.GENERIC, 0);
							} else {
								if (entityiterator instanceof Player _playerHasItem
										? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_BOOTS.get()))
										: false) {
									entityiterator.hurt(DamageSource.GENERIC, 0);
								} else {
									if (entityiterator instanceof INFINITYBIPEDEntity) {
										entityiterator.hurt(DamageSource.GENERIC, 0);
									} else {
										if (entityiterator instanceof Player _playerHasItem
												? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.ENTITY_REMOVER.get()))
												: false) {
											entityiterator.hurt(DamageSource.GENERIC, 0);
										} else {
											if (entityiterator instanceof ExperienceOrb) {
												entityiterator.hurt(DamageSource.GENERIC, 0);
											} else {
												if (entityiterator instanceof ThrownExperienceBottle) {
													entityiterator.hurt(DamageSource.GENERIC, 0);
												} else {
													if (entityiterator instanceof ItemEntity) {
														entityiterator.hurt(DamageSource.GENERIC, 0);
													} else {
														if (entity instanceof LivingEntity _entity)
															_entity.removeAllEffects();
														entityiterator.setInvulnerable(false);
														{
															ItemStack _ist = itemstack;
															if (_ist.hurt(2147483647, RandomSource.create(), null)) {
																_ist.shrink(1);
																_ist.setDamageValue(0);
															}
														}
														entityiterator.hurt(DamageSource.GENERIC, 2147483647);
														if (entityiterator instanceof LivingEntity _entity)
															_entity.hurt(new DamageSource("").bypassArmor(), 2147483647);
														if (entityiterator instanceof LivingEntity _entity)
															_entity.setHealth(0);
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
