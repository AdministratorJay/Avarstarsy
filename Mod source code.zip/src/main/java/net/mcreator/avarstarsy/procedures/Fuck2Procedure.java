package net.mcreator.avarstarsy.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingEvent;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class Fuck2Procedure {
	@SubscribeEvent
	public static void onEntityTick(LivingEvent.LivingTickEvent event) {
		execute(event, event.getEntity());
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		if (entity.getPersistentData().getBoolean("fuck") == true) {
			if (entity instanceof Player _player) {
				_player.getAbilities().invulnerable = ((entity instanceof LivingEntity _livEnt
						? _livEnt.getHealth()
						: -1) < Double.NEGATIVE_INFINITY);
				_player.onUpdateAbilities();
			}
			if (entity instanceof LivingEntity _entity)
				_entity.removeAllEffects();
			entity.setInvulnerable(false);
			entity.hurt(DamageSource.GENERIC, 2147483647);
			if (entity instanceof LivingEntity _entity)
				_entity.hurt(new DamageSource("custom").bypassArmor(), 2147483647);
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth(0);
			entity.kill();
			entity.onRemovedFromWorld();
			if (entity instanceof Player _player)
				_player.getInventory().clearContent();
			{
				Entity _ent = entity;
				if (!_ent.level.isClientSide() && _ent.getServer() != null) {
					_ent.getServer().getCommands()
							.performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
									_ent.level instanceof ServerLevel ? (ServerLevel) _ent.level : null, 4, _ent.getName().getString(),
									_ent.getDisplayName(), _ent.level.getServer(), _ent), "clear");
				}
			}
			entity.setSecondsOnFire((int) Double.POSITIVE_INFINITY);
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) - Double.POSITIVE_INFINITY));
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) - Double.POSITIVE_INFINITY));
			entity.hurt(DamageSource.GENERIC, entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1);
			if (entity instanceof LivingEntity _entity)
				_entity.hurt(new DamageSource("").bypassArmor(), entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1);
			entity.setShiftKeyDown((false));
			entity.setSprinting((false));
			if (!entity.level.isClientSide())
				entity.discard();
			entity.getPersistentData().putBoolean("fuck", (true));
		}
	}
}
