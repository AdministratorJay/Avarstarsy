package net.mcreator.avarstarsy.procedures;

import net.minecraftforge.common.MinecraftForge;

public class StownProcedure {
	public static void execute() {
		MinecraftForge.EVENT_BUS.shutdown();
	}
}
