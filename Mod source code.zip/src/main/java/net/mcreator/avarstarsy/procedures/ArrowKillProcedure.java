package net.mcreator.avarstarsy.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;

import net.mcreator.avarstarsy.init.AvarstarsyModItems;
import net.mcreator.avarstarsy.entity.INFINITYBIPEDEntity;

public class ArrowKillProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _playerHasItem
				? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.ENTITY_REMOVER.get()))
				: false) {
			entity.hurt(DamageSource.GENERIC, 0);
		} else {
			if (entity instanceof Player _playerHasItem
					? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.AVARITIA_ARROW.get()))
					: false) {
				entity.hurt(DamageSource.GENERIC, 0);
			} else {
				if (entity instanceof Player _playerHasItem
						? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_HELMET.get()))
						: false) {
					entity.hurt(DamageSource.GENERIC, 0);
				} else {
					if (entity instanceof Player _playerHasItem
							? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_CHESTPLATE.get()))
							: false) {
						entity.hurt(DamageSource.GENERIC, 0);
					} else {
						if (entity instanceof Player _playerHasItem
								? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_LEGGINGS.get()))
								: false) {
							entity.hurt(DamageSource.GENERIC, 0);
						} else {
							if (entity instanceof Player _playerHasItem
									? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_BOOTS.get()))
									: false) {
								entity.hurt(DamageSource.GENERIC, 0);
							} else {
								if (entity instanceof INFINITYBIPEDEntity) {
									entity.hurt(DamageSource.GENERIC, 0);
								} else {
									if (entity instanceof ExperienceOrb) {
										entity.hurt(DamageSource.GENERIC, 0);
									} else {
										if (entity instanceof ItemEntity) {
											entity.hurt(DamageSource.GENERIC, 0);
										} else {
											entity.hurt(DamageSource.GENERIC, 2147483647);
											if (entity instanceof LivingEntity _entity)
												_entity.hurt(new DamageSource("").bypassArmor(), 2147483647);
											if (entity instanceof LivingEntity _entity)
												_entity.setHealth(0);
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
