package net.mcreator.avarstarsy.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import net.mcreator.avarstarsy.init.AvarstarsyModItems;

public class LogoDangWuPinZaiShouShangMeiKeFaShengProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player) {
			ItemStack _stktoremove = new ItemStack(AvarstarsyModItems.LOGO.get());
			_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), (int) Double.POSITIVE_INFINITY,
					_player.inventoryMenu.getCraftSlots());
		}
		if (entity instanceof Player _player) {
			ItemStack _stktoremove = new ItemStack(AvarstarsyModItems.EMPTYWP.get());
			_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), (int) Double.POSITIVE_INFINITY,
					_player.inventoryMenu.getCraftSlots());
		}
	}
}
