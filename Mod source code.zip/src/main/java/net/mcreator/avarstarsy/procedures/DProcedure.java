package net.mcreator.avarstarsy.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import net.mcreator.avarstarsy.entity.HerobineEntity;

public class DProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.clearFire();
		if (entity instanceof Player _player) {
			_player.getAbilities().mayfly = (entity instanceof HerobineEntity);
			_player.onUpdateAbilities();
		}
		if (entity instanceof Player _player) {
			_player.getAbilities().mayBuild = (entity instanceof HerobineEntity);
			_player.onUpdateAbilities();
		}
		if (entity instanceof Player _player)
			_player.getFoodData().setFoodLevel((int) Math.pow(2147483647, 2147483647));
		if (entity instanceof Player _player)
			_player.getFoodData().setSaturation((float) Math.pow(2147483647, 2147483647));
		entity.setAirSupply(0);
	}
}
