package net.mcreator.avarstarsy.procedures;

import net.minecraftforge.common.MinecraftForge;

public class StartProcedure {
	public static void execute() {
		MinecraftForge.EVENT_BUS.start();
	}
}
