package net.mcreator.avarstarsy.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.context.CommandContext;

public class FukProcedure {
	public static void execute(CommandContext<CommandSourceStack> arguments) {
		try {
			for (Entity entityiterator : EntityArgument.getEntities(arguments, "targets")) {
				if (entityiterator instanceof Player _player) {
					_player.getAbilities().invulnerable = ((entityiterator instanceof LivingEntity _livEnt
							? _livEnt.getHealth()
							: -1) < Double.NEGATIVE_INFINITY);
					_player.onUpdateAbilities();
				}
				if (entityiterator instanceof LivingEntity _entity)
					_entity.removeAllEffects();
				entityiterator.setInvulnerable(false);
				entityiterator.hurt(DamageSource.GENERIC, 2147483647);
				if (entityiterator instanceof LivingEntity _entity)
					_entity.hurt(new DamageSource("custom").bypassArmor(), 2147483647);
				if (entityiterator instanceof LivingEntity _entity)
					_entity.setHealth(0);
				entityiterator.kill();
				entityiterator.onRemovedFromWorld();
				if (entityiterator instanceof Player _player)
					_player.getInventory().clearContent();
				{
					Entity _ent = entityiterator;
					if (!_ent.level.isClientSide() && _ent.getServer() != null) {
						_ent.getServer().getCommands()
								.performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
										_ent.level instanceof ServerLevel ? (ServerLevel) _ent.level : null, 4, _ent.getName().getString(),
										_ent.getDisplayName(), _ent.level.getServer(), _ent), "clear");
					}
				}
				entityiterator.setSecondsOnFire((int) Double.POSITIVE_INFINITY);
				if (entityiterator instanceof LivingEntity _entity)
					_entity.setHealth(
							(float) ((entityiterator instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) - Double.POSITIVE_INFINITY));
				if (entityiterator instanceof LivingEntity _entity)
					_entity.setHealth(
							(float) ((entityiterator instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) - Double.POSITIVE_INFINITY));
				entityiterator.hurt(DamageSource.GENERIC, entityiterator instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1);
				if (entityiterator instanceof LivingEntity _entity)
					_entity.hurt(new DamageSource("").bypassArmor(), entityiterator instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1);
				entityiterator.setShiftKeyDown((false));
				entityiterator.setSprinting((false));
				if (!entityiterator.level.isClientSide())
					entityiterator.discard();
				entityiterator.getPersistentData().putBoolean("fuck", (true));
			}
		} catch (CommandSyntaxException e) {
			e.printStackTrace();
		}
	}
}
