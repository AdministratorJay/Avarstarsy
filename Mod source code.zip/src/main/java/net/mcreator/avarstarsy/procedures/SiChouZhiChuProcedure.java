package net.mcreator.avarstarsy.procedures;

import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.ItemStack;

import java.util.Map;

public class SiChouZhiChuProcedure {
	public static void execute(ItemStack itemstack) {
		if (EnchantmentHelper.getItemEnchantmentLevel(Enchantments.SILK_TOUCH, itemstack) != 0) {
			{
				Map<Enchantment, Integer> _enchantments = EnchantmentHelper.getEnchantments(itemstack);
				if (_enchantments.containsKey(Enchantments.SILK_TOUCH)) {
					_enchantments.remove(Enchantments.SILK_TOUCH);
					EnchantmentHelper.setEnchantments(_enchantments, itemstack);
				}
			}
		} else {
			(itemstack).enchant(Enchantments.SILK_TOUCH, 1);
		}
	}
}
