package net.mcreator.avarstarsy.procedures;

public class CODEProcedure {
	public static void execute() {
		/*entity.world.removeEntity(entity);*/
		/*player.deathTime = 999999;*/
		/*player.ticksExisted = 999999;*/
		/*entity.updateBlocked = false;*/
		/*entity.onKillCommand();*/
		/*entity.onRemovedFromWorld();*/
		/*entity.onRemovedFromWorld();*/
		/*entity.world.removeEntity(entityiterator);*/
		/*entity.preventEntitySpawning = false;*/
		/*entity.setEntityInvulnerable(false);*/
		/*entity.setDead();*/
		/*entity.isDead = true;*/
		/*world.getChunk(entity.chunkCoordX, entity.chunkCoordZ).removeEntity(entity);*/
		/*world.loadedEntityList.remove(entity);entity.updateBlocked = true;*/
		/*entity.motionX = entity.motionY = entity.motionZ = 0;entity.lastTickPosX = entity.posX = entity.prevPosX = Double.NaN;entity.lastTickPosY = entity.posY = entity.prevPosY = Double.NaN;entity.lastTickPosZ = entity.posZ = entity.prevPosZ = Double.NaN;*/
		/*entity.noClip = true;entity.collided = entity.collidedVertically = entity.collidedHorizontally = false;entity.forceSpawn = false;entity.velocityChanged = true;*/
		/*entity.onUpdate();*/
	}
}
