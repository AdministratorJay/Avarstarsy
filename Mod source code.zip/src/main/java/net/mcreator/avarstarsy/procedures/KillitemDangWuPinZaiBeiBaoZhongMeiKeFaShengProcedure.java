package net.mcreator.avarstarsy.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.avarstarsy.init.AvarstarsyModItems;

public class KillitemDangWuPinZaiBeiBaoZhongMeiKeFaShengProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _playerHasItem
				? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.ENTITY_REMOVER.get()))
				: false) {
			{
				Entity _ent = entity;
				if (!_ent.level.isClientSide() && _ent.getServer() != null) {
					_ent.getServer().getCommands()
							.performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
									_ent.level instanceof ServerLevel ? (ServerLevel) _ent.level : null, 4, _ent.getName().getString(),
									_ent.getDisplayName(), _ent.level.getServer(), _ent), "");
				}
			}
		} else {
			if (entity instanceof Player _player) {
				_player.getAbilities().invulnerable = ((entity instanceof LivingEntity _livEnt
						? _livEnt.getMaxHealth()
						: -1) > Double.POSITIVE_INFINITY);
				_player.onUpdateAbilities();
			}
			if (entity instanceof LivingEntity _entity)
				_entity.removeAllEffects();
			entity.hurt(DamageSource.GENERIC, 2147483647);
			if (entity instanceof LivingEntity _entity)
				_entity.hurt(new DamageSource("custom").bypassArmor(), 2147483647);
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth(0);
			entity.onRemovedFromWorld();
			if (!entity.level.isClientSide())
				entity.discard();
			entity.getPersistentData().putBoolean("fcbsdjerjkgbghjbdjekwdbeejnewjknfjnkewjnkfjnkfjknf", (true));
		}
	}
}
