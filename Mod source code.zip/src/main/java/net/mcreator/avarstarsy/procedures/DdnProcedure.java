package net.mcreator.avarstarsy.procedures;

import net.minecraft.world.entity.Entity;

public class DdnProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.getPersistentData().putBoolean("nokeep", (true));
	}
}
