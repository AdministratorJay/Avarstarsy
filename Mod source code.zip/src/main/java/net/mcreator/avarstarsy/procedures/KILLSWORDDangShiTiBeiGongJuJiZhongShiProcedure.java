package net.mcreator.avarstarsy.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;

public class KILLSWORDDangShiTiBeiGongJuJiZhongShiProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.hurt(DamageSource.GENERIC, (float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
				+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));
		if (entity instanceof LivingEntity _entity)
			_entity.hurt(new DamageSource("").bypassArmor(), (float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
					+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));
		entity.hurt(DamageSource.GENERIC, (float) Math.pow(128, 100));
		if (entity instanceof LivingEntity _entity)
			_entity.hurt(new DamageSource("").bypassArmor(), (float) Math.pow(128, 100));
		entity.hurt(DamageSource.GENERIC, (float) Double.POSITIVE_INFINITY);
		if (entity instanceof LivingEntity _entity)
			_entity.hurt(new DamageSource("").bypassArmor(), (float) Double.POSITIVE_INFINITY);/*entity.updateBlocked = false;*/
		/*entity.setEntityInvulnerable(false);*/
		/*entity.onKillCommand();*/
		/*entity.isDead = true;*/
		/*entity.setDead();*/
		/*entity.onUpdate();*/
		/*entity.world.removeEntity(entity);*/
	}
}
