package net.mcreator.avarstarsy.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.util.RandomSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.avarstarsy.init.AvarstarsyModItems;

public class Kill2Procedure {
	public static void execute(Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		if (entity instanceof Player _playerHasItem
				? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.ENTITY_REMOVER.get()))
				: false) {
			{
				Entity _ent = entity;
				if (!_ent.level.isClientSide() && _ent.getServer() != null) {
					_ent.getServer().getCommands()
							.performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
									_ent.level instanceof ServerLevel ? (ServerLevel) _ent.level : null, 4, _ent.getName().getString(),
									_ent.getDisplayName(), _ent.level.getServer(), _ent), "");
				}
			}
		} else {
			if (entity instanceof LivingEntity _entity)
				_entity.removeAllEffects();
			entity.setInvulnerable(false);
			{
				ItemStack _ist = itemstack;
				if (_ist.hurt(2147483647, RandomSource.create(), null)) {
					_ist.shrink(1);
					_ist.setDamageValue(0);
				}
			}
			entity.hurt(DamageSource.GENERIC, 2147483647);
			if (entity instanceof LivingEntity _entity)
				_entity.hurt(new DamageSource("").bypassArmor(), 2147483647);
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth(0);
		}
	}
}
