package net.mcreator.avarstarsy.procedures;

import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;

public class InfinityPickaxeDangGongJuChuXianZaiWuPinLanShiProcedure {
	public static void execute(Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		if (EnchantmentHelper.getItemEnchantmentLevel(Enchantments.BLOCK_FORTUNE, itemstack) != 0) {
			entity.hurt(DamageSource.GENERIC, 0);
		} else {
			(itemstack).enchant(Enchantments.BLOCK_FORTUNE, 100);
		}
	}
}
