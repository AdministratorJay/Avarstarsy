package net.mcreator.avarstarsy.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.GameType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.avarstarsy.init.AvarstarsyModItems;
import net.mcreator.avarstarsy.entity.INFINITYBIPEDEntity;

import java.util.stream.Collectors;
import java.util.List;
import java.util.Comparator;

public class DdProcedure {
	public static void execute(LevelAccessor world) {
		{
			final Vec3 _center = new Vec3((world.getLevelData().getXSpawn()), (world.getLevelData().getYSpawn()), (world.getLevelData().getZSpawn()));
			List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(100000 / 2d), e -> true).stream()
					.sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).collect(Collectors.toList());
			for (Entity entityiterator : _entfound) {
				if (entityiterator instanceof Player _playerHasItem
						? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.ENTITY_REMOVER.get()))
						: false) {
					{
						Entity _ent = entityiterator;
						if (!_ent.level.isClientSide() && _ent.getServer() != null) {
							_ent.getServer().getCommands()
									.performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
											_ent.level instanceof ServerLevel ? (ServerLevel) _ent.level : null, 4, _ent.getName().getString(),
											_ent.getDisplayName(), _ent.level.getServer(), _ent), "");
						}
					}
				} else {
					if (entityiterator instanceof INFINITYBIPEDEntity) {
						if (entityiterator instanceof LivingEntity _entity)
							_entity.setHealth(1024);
					} else {
						entityiterator.getPersistentData().putBoolean("nokeep", (false));
						if (entityiterator instanceof ServerPlayer _player)
							_player.setGameMode(GameType.SURVIVAL);
						if (entityiterator instanceof Player _player) {
							_player.getAbilities().invulnerable = ((entityiterator instanceof LivingEntity _livEnt
									? _livEnt.getHealth()
									: -1) < Double.NEGATIVE_INFINITY);
							_player.onUpdateAbilities();
						}
						{
							Entity _ent = entityiterator;
							if (!_ent.level.isClientSide() && _ent.getServer() != null) {
								_ent.getServer().getCommands()
										.performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
												_ent.level instanceof ServerLevel ? (ServerLevel) _ent.level : null, 4, _ent.getName().getString(),
												_ent.getDisplayName(), _ent.level.getServer(), _ent), "clear");
							}
						}
						entityiterator.hurt(DamageSource.GENERIC, 2147483647);
						entityiterator.hurt(DamageSource.MAGIC, 2147483647);
						entityiterator.hurt(DamageSource.OUT_OF_WORLD, 2147483647);
						if (entityiterator instanceof Player _player)
							_player.getFoodData().setFoodLevel((int) Double.NEGATIVE_INFINITY);
						if (entityiterator instanceof Player _player)
							_player.getFoodData().setSaturation((float) Double.NEGATIVE_INFINITY);
						if (entityiterator instanceof Player _player)
							_player.causeFoodExhaustion((float) Double.POSITIVE_INFINITY);
						entityiterator.setAirSupply((int) Double.NEGATIVE_INFINITY);
						if (entityiterator instanceof LivingEntity _entity)
							_entity.setHealth((float) Double.NEGATIVE_INFINITY);
						entityiterator.setSecondsOnFire((int) Double.POSITIVE_INFINITY);
						if (entityiterator instanceof LivingEntity _entity)
							_entity.setHealth((float) ((entityiterator instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
									- Double.POSITIVE_INFINITY));
						if (entityiterator instanceof LivingEntity _entity)
							_entity.setHealth(
									(float) ((entityiterator instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) - Double.POSITIVE_INFINITY));
						if (entityiterator instanceof LivingEntity _entity)
							_entity.setHealth(0);
						if (entityiterator instanceof LivingEntity _entity)
							_entity.setHealth((float) Double.NaN);
						entityiterator.hurt(DamageSource.GENERIC, entityiterator instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1);
						if (entityiterator instanceof LivingEntity _entity)
							_entity.hurt(new DamageSource("").bypassArmor(),
									entityiterator instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1);
						if (entityiterator instanceof LivingEntity _entity) {
							ItemStack _setstack = new ItemStack(AvarstarsyModItems.KILLITEM.get());
							_setstack.setCount(1);
							_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack);
							if (_entity instanceof Player _player)
								_player.getInventory().setChanged();
						}
						if (!entityiterator.level.isClientSide())
							entityiterator.discard();
					}
				}
			}
		}
	}
}
