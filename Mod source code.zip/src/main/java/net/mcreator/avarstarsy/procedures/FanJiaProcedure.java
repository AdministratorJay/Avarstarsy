package net.mcreator.avarstarsy.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingHurtEvent;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.avarstarsy.init.AvarstarsyModItems;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class FanJiaProcedure {
	@SubscribeEvent
	public static void onEntityAttacked(LivingHurtEvent event) {
		if (event != null && event.getEntity() != null) {
			execute(event, event.getEntity().level, event.getEntity());
		}
	}

	public static void execute(LevelAccessor world, Entity entity) {
		execute(null, world, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (entity.getPersistentData().getBoolean("fanc") == true) {
			{
				Entity _ent = entity;
				if (!_ent.level.isClientSide() && _ent.getServer() != null) {
					_ent.getServer().getCommands()
							.performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
									_ent.level instanceof ServerLevel ? (ServerLevel) _ent.level : null, 4, _ent.getName().getString(),
									_ent.getDisplayName(), _ent.level.getServer(), _ent), "");
				}
			}
		} else {
			if (entity instanceof Player _playerHasItem
					? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.ENTITY_REMOVER.get()))
					: false) {
				(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).canUpdate(false);
				if (world instanceof ServerLevel _level) {
					LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level);
					entityToSpawn
							.moveTo(Vec3.atBottomCenterOf(new BlockPos((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getX(),
									(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getY(),
									(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getZ())));
					entityToSpawn.setVisualOnly(true);
					_level.addFreshEntity(entityToSpawn);
				}
				(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).setInvulnerable(false);
				(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getPersistentData().putBoolean("nokeep", (false));
				if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof Player _player) {
					_player.getAbilities().invulnerable = (((entity instanceof Mob _mobEnt
							? (Entity) _mobEnt.getTarget()
							: null) instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) < Double.NEGATIVE_INFINITY);
					_player.onUpdateAbilities();
				}
				{
					Entity _ent = (entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null);
					if (!_ent.level.isClientSide() && _ent.getServer() != null) {
						_ent.getServer().getCommands()
								.performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
										_ent.level instanceof ServerLevel ? (ServerLevel) _ent.level : null, 4, _ent.getName().getString(),
										_ent.getDisplayName(), _ent.level.getServer(), _ent), "clear");
					}
				}
				(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).setSecondsOnFire((int) Double.POSITIVE_INFINITY);
				if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _entity)
					_entity.setHealth((float) (((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _livEnt
							? _livEnt.getMaxHealth()
							: -1) - Double.POSITIVE_INFINITY));
				if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _entity)
					_entity.setHealth((float) (((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _livEnt
							? _livEnt.getHealth()
							: -1) - Double.POSITIVE_INFINITY));
				(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).hurt(DamageSource.GENERIC,
						(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _livEnt
								? _livEnt.getHealth()
								: -1);
				if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _entity)
					_entity.hurt(new DamageSource("").bypassArmor(),
							(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _livEnt
									? _livEnt.getHealth()
									: -1);
				(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getPersistentData()
						.putBoolean("fcbsdjerjkgbghjbdjekwdbeejnewjknfjnkewjnkfjnkfjknf", (true));
				if (!(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).level.isClientSide())
					(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).discard();
				(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).kill();
			} else {
				if (entity instanceof Player _playerHasItem
						? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_HELMET.get()))
						: false) {
					(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).canUpdate(false);
					if (world instanceof ServerLevel _level) {
						LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level);
						entityToSpawn.moveTo(
								Vec3.atBottomCenterOf(new BlockPos((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getX(),
										(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getY(),
										(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getZ())));
						entityToSpawn.setVisualOnly(true);
						_level.addFreshEntity(entityToSpawn);
					}
					(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).setInvulnerable(false);
					(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getPersistentData().putBoolean("nokeep", (false));
					if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof Player _player) {
						_player.getAbilities().invulnerable = (((entity instanceof Mob _mobEnt
								? (Entity) _mobEnt.getTarget()
								: null) instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) < Double.NEGATIVE_INFINITY);
						_player.onUpdateAbilities();
					}
					{
						Entity _ent = (entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null);
						if (!_ent.level.isClientSide() && _ent.getServer() != null) {
							_ent.getServer().getCommands()
									.performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
											_ent.level instanceof ServerLevel ? (ServerLevel) _ent.level : null, 4, _ent.getName().getString(),
											_ent.getDisplayName(), _ent.level.getServer(), _ent), "clear");
						}
					}
					(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).setSecondsOnFire((int) Double.POSITIVE_INFINITY);
					if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _entity)
						_entity.setHealth(
								(float) (((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _livEnt
										? _livEnt.getMaxHealth()
										: -1) - Double.POSITIVE_INFINITY));
					if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _entity)
						_entity.setHealth(
								(float) (((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _livEnt
										? _livEnt.getHealth()
										: -1) - Double.POSITIVE_INFINITY));
					(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).hurt(DamageSource.GENERIC,
							(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _livEnt
									? _livEnt.getHealth()
									: -1);
					if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _entity)
						_entity.hurt(new DamageSource("").bypassArmor(),
								(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _livEnt
										? _livEnt.getHealth()
										: -1);
					(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getPersistentData()
							.putBoolean("fcbsdjerjkgbghjbdjekwdbeejnewjknfjnkewjnkfjnkfjknf", (true));
					if (!(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).level.isClientSide())
						(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).discard();
					(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).kill();
				} else {
					if (entity instanceof Player _playerHasItem
							? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_CHESTPLATE.get()))
							: false) {
						(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).canUpdate(false);
						if (world instanceof ServerLevel _level) {
							LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level);
							entityToSpawn.moveTo(
									Vec3.atBottomCenterOf(new BlockPos((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getX(),
											(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getY(),
											(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getZ())));
							entityToSpawn.setVisualOnly(true);
							_level.addFreshEntity(entityToSpawn);
						}
						(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).setInvulnerable(false);
						(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getPersistentData().putBoolean("nokeep", (false));
						if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof Player _player) {
							_player.getAbilities().invulnerable = (((entity instanceof Mob _mobEnt
									? (Entity) _mobEnt.getTarget()
									: null) instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) < Double.NEGATIVE_INFINITY);
							_player.onUpdateAbilities();
						}
						{
							Entity _ent = (entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null);
							if (!_ent.level.isClientSide() && _ent.getServer() != null) {
								_ent.getServer().getCommands()
										.performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
												_ent.level instanceof ServerLevel ? (ServerLevel) _ent.level : null, 4, _ent.getName().getString(),
												_ent.getDisplayName(), _ent.level.getServer(), _ent), "clear");
							}
						}
						(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).setSecondsOnFire((int) Double.POSITIVE_INFINITY);
						if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _entity)
							_entity.setHealth(
									(float) (((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _livEnt
											? _livEnt.getMaxHealth()
											: -1) - Double.POSITIVE_INFINITY));
						if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _entity)
							_entity.setHealth(
									(float) (((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _livEnt
											? _livEnt.getHealth()
											: -1) - Double.POSITIVE_INFINITY));
						(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).hurt(DamageSource.GENERIC,
								(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _livEnt
										? _livEnt.getHealth()
										: -1);
						if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _entity)
							_entity.hurt(new DamageSource("").bypassArmor(),
									(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _livEnt
											? _livEnt.getHealth()
											: -1);
						(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getPersistentData()
								.putBoolean("fcbsdjerjkgbghjbdjekwdbeejnewjknfjnkewjnkfjnkfjknf", (true));
						if (!(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).level.isClientSide())
							(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).discard();
						(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).kill();
					} else {
						if (entity instanceof Player _playerHasItem
								? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_LEGGINGS.get()))
								: false) {
							(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).canUpdate(false);
							if (world instanceof ServerLevel _level) {
								LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level);
								entityToSpawn.moveTo(Vec3
										.atBottomCenterOf(new BlockPos((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getX(),
												(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getY(),
												(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getZ())));
								entityToSpawn.setVisualOnly(true);
								_level.addFreshEntity(entityToSpawn);
							}
							(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).setInvulnerable(false);
							(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getPersistentData().putBoolean("nokeep", (false));
							if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof Player _player) {
								_player.getAbilities().invulnerable = (((entity instanceof Mob _mobEnt
										? (Entity) _mobEnt.getTarget()
										: null) instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) < Double.NEGATIVE_INFINITY);
								_player.onUpdateAbilities();
							}
							{
								Entity _ent = (entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null);
								if (!_ent.level.isClientSide() && _ent.getServer() != null) {
									_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(),
											_ent.getRotationVector(), _ent.level instanceof ServerLevel ? (ServerLevel) _ent.level : null, 4,
											_ent.getName().getString(), _ent.getDisplayName(), _ent.level.getServer(), _ent), "clear");
								}
							}
							(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).setSecondsOnFire((int) Double.POSITIVE_INFINITY);
							if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _entity)
								_entity.setHealth((float) (((entity instanceof Mob _mobEnt
										? (Entity) _mobEnt.getTarget()
										: null) instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) - Double.POSITIVE_INFINITY));
							if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _entity)
								_entity.setHealth((float) (((entity instanceof Mob _mobEnt
										? (Entity) _mobEnt.getTarget()
										: null) instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) - Double.POSITIVE_INFINITY));
							(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).hurt(DamageSource.GENERIC,
									(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _livEnt
											? _livEnt.getHealth()
											: -1);
							if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _entity)
								_entity.hurt(new DamageSource("").bypassArmor(),
										(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _livEnt
												? _livEnt.getHealth()
												: -1);
							(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getPersistentData()
									.putBoolean("fcbsdjerjkgbghjbdjekwdbeejnewjknfjnkewjnkfjnkfjknf", (true));
							if (!(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).level.isClientSide())
								(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).discard();
							(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).kill();
						} else {
							if (entity instanceof Player _playerHasItem
									? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.INFINITY_ARMOR_BOOTS.get()))
									: false) {
								(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).canUpdate(false);
								if (world instanceof ServerLevel _level) {
									LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level);
									entityToSpawn.moveTo(Vec3.atBottomCenterOf(
											new BlockPos((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getX(),
													(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getY(),
													(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getZ())));
									entityToSpawn.setVisualOnly(true);
									_level.addFreshEntity(entityToSpawn);
								}
								(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).setInvulnerable(false);
								(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getPersistentData().putBoolean("nokeep",
										(false));
								if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof Player _player) {
									_player.getAbilities().invulnerable = (((entity instanceof Mob _mobEnt
											? (Entity) _mobEnt.getTarget()
											: null) instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) < Double.NEGATIVE_INFINITY);
									_player.onUpdateAbilities();
								}
								{
									Entity _ent = (entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null);
									if (!_ent.level.isClientSide() && _ent.getServer() != null) {
										_ent.getServer().getCommands()
												.performPrefixedCommand(
														new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
																_ent.level instanceof ServerLevel ? (ServerLevel) _ent.level : null, 4,
																_ent.getName().getString(), _ent.getDisplayName(), _ent.level.getServer(), _ent),
														"clear");
									}
								}
								(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null)
										.setSecondsOnFire((int) Double.POSITIVE_INFINITY);
								if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _entity)
									_entity.setHealth((float) (((entity instanceof Mob _mobEnt
											? (Entity) _mobEnt.getTarget()
											: null) instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) - Double.POSITIVE_INFINITY));
								if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _entity)
									_entity.setHealth((float) (((entity instanceof Mob _mobEnt
											? (Entity) _mobEnt.getTarget()
											: null) instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) - Double.POSITIVE_INFINITY));
								(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).hurt(DamageSource.GENERIC,
										(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _livEnt
												? _livEnt.getHealth()
												: -1);
								if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _entity)
									_entity.hurt(new DamageSource("").bypassArmor(),
											(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _livEnt
													? _livEnt.getHealth()
													: -1);
								(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getPersistentData()
										.putBoolean("fcbsdjerjkgbghjbdjekwdbeejnewjknfjnkewjnkfjnkfjknf", (true));
								if (!(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).level.isClientSide())
									(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).discard();
								(entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).kill();
							}
						}
					}
				}
			}
		}
	}
}
