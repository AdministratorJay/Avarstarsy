package net.mcreator.avarstarsy.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.avarstarsy.init.AvarstarsyModItems;

public class InfinityArmorTouKuiShiJianMeiYouXiKeProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _playerHasItem
				? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.ENTITY_REMOVER.get()))
				: false) {
			entity.canUpdate(true);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.DIG_SLOWDOWN);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.HEAL);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.CONFUSION);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.BLINDNESS);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.HUNGER);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.WEAKNESS);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.POISON);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.WITHER);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.GLOWING);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.LEVITATION);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.UNLUCK);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.DARKNESS);
			entity.clearFire();
			if (entity instanceof LivingEntity _entity)
				_entity.addEffect(new MobEffectInstance(MobEffects.HEALTH_BOOST, 180, 5, (false), (false)));
			if (entity instanceof LivingEntity _entity)
				_entity.addEffect(new MobEffectInstance(MobEffects.HEAL, 180, 2147483647, (false), (false)));
			if (entity instanceof LivingEntity _entity)
				_entity.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 9999, (false), (false)));
			entity.clearFire();
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth((float) Double.POSITIVE_INFINITY);
			if (entity instanceof Player _player) {
				_player.getAbilities().mayfly = (entity instanceof Player _playerHasItem
						? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.ENTITY_REMOVER.get()))
						: false);
				_player.onUpdateAbilities();
			}
			if (entity instanceof Player _player) {
				_player.getAbilities().mayBuild = (entity instanceof Player _playerHasItem
						? _playerHasItem.getInventory().contains(new ItemStack(AvarstarsyModItems.ENTITY_REMOVER.get()))
						: false);
				_player.onUpdateAbilities();
			}
			if (entity instanceof Player _player)
				_player.getFoodData().setFoodLevel((int) Double.POSITIVE_INFINITY);
			if (entity instanceof Player _player)
				_player.getFoodData().setSaturation((float) Double.POSITIVE_INFINITY);
			entity.setAirSupply(0);
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) + Double.POSITIVE_INFINITY));
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)
						+ (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)));
		}
	}
}
