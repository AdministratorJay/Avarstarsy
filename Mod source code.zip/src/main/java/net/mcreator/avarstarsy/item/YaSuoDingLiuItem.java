
package net.mcreator.avarstarsy.item;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

import net.mcreator.avarstarsy.init.AvarstarsyModTabs;

public class YaSuoDingLiuItem extends Item {
	public YaSuoDingLiuItem() {
		super(new Item.Properties().tab(AvarstarsyModTabs.TAB_AVARSTARSY).stacksTo(64).fireResistant().rarity(Rarity.EPIC));
	}

	@Override
	public float getDestroySpeed(ItemStack par1ItemStack, BlockState par2Block) {
		return 128000F;
	}
}
