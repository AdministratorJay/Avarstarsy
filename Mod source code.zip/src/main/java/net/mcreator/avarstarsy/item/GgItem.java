
package net.mcreator.avarstarsy.item;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.LivingEntity;

import net.mcreator.avarstarsy.procedures.GgDangShiTiHuiDongWuPinShiProcedure;
import net.mcreator.avarstarsy.procedures.GgDangShiTiBeiGongJuJiZhongShiProcedure;
import net.mcreator.avarstarsy.init.AvarstarsyModTabs;
import net.mcreator.avarstarsy.init.AvarstarsyModItems;

public class GgItem extends SwordItem {
	public GgItem() {
		super(new Tier() {
			public int getUses() {
				return 0;
			}

			public float getSpeed() {
				return 128000f;
			}

			public float getAttackDamageBonus() {
				return 127998f;
			}

			public int getLevel() {
				return 128000;
			}

			public int getEnchantmentValue() {
				return 128000;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of(new ItemStack(AvarstarsyModItems.INFINITY_INGOT.get()));
			}
		}, 3, 96f, new Item.Properties().tab(AvarstarsyModTabs.TAB_AVARSTARSY).fireResistant());
	}

	@Override
	public boolean hurtEnemy(ItemStack itemstack, LivingEntity entity, LivingEntity sourceentity) {
		boolean retval = super.hurtEnemy(itemstack, entity, sourceentity);
		GgDangShiTiBeiGongJuJiZhongShiProcedure.execute(entity);
		return retval;
	}

	@Override
	public boolean onEntitySwing(ItemStack itemstack, LivingEntity entity) {
		boolean retval = super.onEntitySwing(itemstack, entity);
		GgDangShiTiHuiDongWuPinShiProcedure.execute(entity.level, entity.getX(), entity.getY(), entity.getZ());
		return retval;
	}
}
