
package net.mcreator.avarstarsy.item;

import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.InteractionResult;

import net.mcreator.avarstarsy.procedures.InfinitybipedspawneggDangYouJianDianJiFangKuaiShiFangKuaiDeWeiZhiProcedure;
import net.mcreator.avarstarsy.init.AvarstarsyModTabs;

public class InfinitybipedspawneggItem extends Item {
	public InfinitybipedspawneggItem() {
		super(new Item.Properties().tab(AvarstarsyModTabs.TAB_AVARSTARSY).stacksTo(64).rarity(Rarity.EPIC));
	}

	@Override
	public InteractionResult useOn(UseOnContext context) {
		super.useOn(context);
		InfinitybipedspawneggDangYouJianDianJiFangKuaiShiFangKuaiDeWeiZhiProcedure.execute(context.getLevel(), context.getClickedPos().getX(),
				context.getClickedPos().getY(), context.getClickedPos().getZ());
		return InteractionResult.SUCCESS;
	}
}
