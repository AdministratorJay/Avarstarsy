
package net.mcreator.avarstarsy.item;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.LivingEntity;

import net.mcreator.avarstarsy.procedures.Az22Procedure;
import net.mcreator.avarstarsy.init.AvarstarsyModTabs;
import net.mcreator.avarstarsy.init.AvarstarsyModItems;

public class Az11Item extends SwordItem {
	public Az11Item() {
		super(new Tier() {
			public int getUses() {
				return 0;
			}

			public float getSpeed() {
				return 128000f;
			}

			public float getAttackDamageBonus() {
				return 127998f;
			}

			public int getLevel() {
				return 128000;
			}

			public int getEnchantmentValue() {
				return 128000;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of(new ItemStack(AvarstarsyModItems.INFINITY_INGOT.get()));
			}
		}, 3, 96f, new Item.Properties().tab(AvarstarsyModTabs.TAB_AVARSTARSY).fireResistant());
	}

	@Override
	public boolean onEntitySwing(ItemStack itemstack, LivingEntity entity) {
		boolean retval = super.onEntitySwing(itemstack, entity);
		Az22Procedure.execute(entity.level, entity.getX(), entity.getY(), entity.getZ());
		return retval;
	}
}
